---
name: company-background-check-xlsx
displayName: "公司背调报告"
displayDescription: "用 Search、Fetch 与 Accio Browser Relay 核验公司主体并生成可追溯 Excel 背调报告"
description: 国家 + 公司名背调报告 XLSX 技能。使用 Accio 的 web_search、web_fetch、ask_user 和 browser 核验正确官网、公司业务、公开联系人、风险与合作价值，生成带来源、缺失项和开发行动计划的三 Sheet Excel。
---

# 公司背调报告 XLSX

把“国家/地区 + 公司名”变成一份能直接给外贸业务员使用的公司背调 Excel。执行顺序固定为 Search → Fetch → Accio Browser Relay → 证据归一化 → Excel。所有事实必须落到公开来源；未找到、冲突、过期或只来自搜索摘要的内容必须显式标记，不得用推断填满报告。

本 Skill 不接入第三方付费采集平台，不购买联系人数据库，不绕过登录或验证码，也不把公开页面访问等同于对方授权联系。

## 1. 标准交付

最终 Excel 只保留三个可见工作表：

1. `背调报告`：十个业务章节、每项结论、来源和置信说明；
2. `联系信息`：公开企业联系路径、公开职业联系人、证据与 BD 优先级；
3. `开发行动计划`：从主体确认、首轮触达、产品切入、报价样品到风险复核的动作清单。

同时生成同名 `.log`。只有 Excel 能重新打开、三个 Sheet 齐全、包结构校验通过，才可交付。

## 2. 工具契约

| 顺序 | 工具 | 责任 |
| --- | --- | --- |
| 1 | `ask_user` | 补齐主体、国家、我司产品与报告用途；处理同名公司歧义 |
| 2 | `web_search` | 识别候选官网与多源公开证据 |
| 3 | `web_fetch` | 读取官网、About、Contact、Products、News、Team 等正文 |
| 4 | `browser` | Accio Browser Relay 白名单标识；只读复核动态公开页面、最终 URL 和页面可见字段 |
| 5 | `scripts/build_report_xlsx.py` | 把规范化 JSON 渲染成安全 Excel 并完成重开校验 |
| 6 | `spreadsheets` / `present_files` | 复核并向用户交付真实文件 |

`browser` 对应 Accio Browser Relay。若运行时拆成 `browser_*` 工具，只使用实际暴露的打开、导航、读取和关闭标签页能力，不猜测工具名。浏览器默认只读；登录、授权、验证码、提交表单、下载未知文件、发送消息或改变外部状态时必须停止。

## 3. 输入门禁

最少必填：

- `country`：目标公司所在国家/地区；
- `company_name`：公司名称，尽量保留完整法律名或品牌名。

会显著改变报告判断时再补问：

- 用户掌握的官网、地址、产品或联系人线索；
- 背调用途：初筛、报价前、寄样前、授信前或重点客户开发；
- 我司产品、优势、MOQ、认证、价格带和目标合作模式；
- 是否需要重点查进口环境、关键决策人、合规风险或竞争格局。

用户没有提供我司信息时可以完成客观公司背调，但“对我司价值、切入产品、报价与样品策略”必须写 `缺少我司信息，待补充后判断`。

## 4. 第一步：Search 识别正确主体

先执行至少三类查询：

```text
"{company_name}" {country} official website
"{company_name}" {country} about contact
"{company_name}" {country} products
"{company_name}" {country} LinkedIn
"{company_name}" {country} registration news
```

为每个候选记录：公司名、URL、域名、国家/地址线索、产品线索、搜索摘要、来源类型和访问日期。不能因为搜索结果排第一就认定是官网。

官网确认至少满足两项：

1. 官网公司名或品牌名与目标一致；
2. About/Contact 的地址、电话、国家与目标一致；
3. 产品或业务与用户线索一致；
4. 权威公司页、行业目录或官方社媒链接回该域名；
5. 域名邮箱、法律页或隐私页能对应同一主体。

以下情况必须 `ask_user` 确认后再继续：同名集团与子公司并存；品牌名与法律主体不同；不同国家存在同名公司；官网候选产品完全不同；用户提供的域名与公开证据冲突。

## 5. 第二步：建立研究矩阵

围绕报告十章节建立查询矩阵，不要只搜公司名：

| 章节 | Search 方向 |
| --- | --- |
| 客户类型 | importer / wholesaler / distributor / brand / retailer / manufacturer |
| 公司介绍 | official site / about / contact / locations / legal name |
| 公司实力 | founded / employees / offices / certifications / exhibitions / media |
| 产品与销售 | products / brands / catalog / pricing / dealer / store locator |
| 联系人 | team / leadership / sales / sourcing / procurement / LinkedIn |
| 进口环境 | import records / HS code / country industry imports / tariffs |
| 风险 | sanctions / litigation / recall / complaints / insolvency / data breach |
| 合作价值 | product gap / channel fit / supplier / OEM / private label |
| 开发话术 | pain point / target customer / product positioning / recent news |
| 竞争格局 | competitors / alternatives / distributors / market positioning |

公司层面的进口记录与国家/行业进口趋势必须分开。找不到公司级记录时写明“未找到可靠公开公司级进口数据”，不能拿国家统计替代。

## 6. 第三步：Fetch 回读正文

优先 Fetch：

- 官网首页、About、Contact、Locations；
- Products、Brands、Catalog、Wholesale、Dealer；
- Team、Leadership、Careers；
- News、Press、Blog、Project/Case；
- 官方社媒公司页、权威行业组织、政府/监管、主流新闻；
- 与进口、合规、风险相关的权威公开来源。

每条证据使用统一记录：

```json
{
  "source_type": "official_website",
  "title": "About Example Company",
  "url": "https://www.example.com/about",
  "publisher": "Example Company",
  "published_at": "未找到可靠公开信息",
  "accessed_at": "2026-08-27",
  "claim": "公司在波兰设有总部并经营工业泵分销",
  "evidence": "页面明确列出总部地址、产品类别与经销业务",
  "confidence": "high"
}
```

Fetch 返回空壳、脚本页或拒绝正文时，不反复请求；转到 Browser Relay 做只读复核，或改找同一事实的其他公开来源。

## 7. 第四步：Accio Browser Relay 复核

仅在以下情况使用 `browser`：

- 官网或社媒为动态页面，Fetch 无法读取；
- 需要确认搜索结果的最终跳转 URL；
- 需要查看公开可见的公司名、地址、联系方式、团队、产品或页面日期；
- 同名主体冲突，需要核对页面视觉身份、地区和外链；
- 需要浏览少量公开分页才能找到目标证据。

操作顺序：打开候选 URL → 等待页面稳定 → 记录标题、最终 URL 与访问时间 → 读取与当前报告字段直接相关的公开可见信息 → 必要时点击 About/Contact/Products 等公开导航 → 将证据归一化为 `browser_evidence.raw_items` → 关闭无关标签。

遇到登录墙、验证码、地区限制、频控、私密页面或无法读取的嵌入内容时立即停止该来源。不得让用户提供 Cookie、Token 或密码，不使用浏览器绕过站点限制。

## 8. 主体、事实与判断的分层

报告中的每个值必须标记为以下之一：

- `verified_fact`：官网或权威来源明确支持；
- `supported_inference`：两个以上事实支持的业务判断，必须写判断逻辑；
- `user_input`：用户提供，尚未公开核验时要注明；
- `not_found`：未找到可靠公开信息；
- `conflict`：来源冲突，保留双方并说明；
- `stale`：信息可能过期，写明页面日期或访问日期。

不得推断或编造营收、员工数、进口量、采购量、付款能力、联系人邮箱、制裁结论、诉讼结果或合作意愿。搜索摘要只能做导航，不能单独支撑高风险结论。

## 9. 联系信息与隐私边界

`联系信息` 只收录：

- 官网公开企业邮箱、业务电话、总机、联系表单；
- 公司页公开列出的职业联系人；
- 公开职业主页中的姓名、职位和公司关系；
- 对业务开发有必要且能回溯到 URL 的企业联系路径。

不收录私人邮箱、私人手机号、家庭住址、群组成员、互动用户或通过域名规则猜出的邮箱。联系人是否参与采购只能写“可能相关”并说明职位依据，不能写成已确认决策人。

优先级评分建议：工作邮箱 25、公司域名匹配 10、职业主页 10、采购/供应链/运营相关职位 25、经理及以上层级 15、目标国家匹配 5、来源明确 10。缺少工作邮箱不代表无价值，但必须降低可直接联系性。

## 10. 十章节报告契约

`背调报告` 必须覆盖：

1. 客户类型判断；
2. 公司介绍；
3. 公司实力分析；
4. 产品线与销售能力；
5. 关键决策人员与联络建议；
6. 近三年进口相关数据与采购环境；
7. 风险与注意事项；
8. 对我司的合作价值与切入建议；
9. 开发话术建议；
10. 综合结论。

每个章节字段都应包含 `value`、`source`、`confidence`。未找到的数据保留字段并填 `未找到可靠公开信息`，不要删除字段造成“似乎无缺口”的错觉。

## 11. 规范化 JSON 输入

脚本读取的核心结构：

```json
{
  "input": {
    "country": "Poland",
    "company_name": "Example Pumps",
    "purpose": "报价前背调",
    "our_company_context": "我司工业泵 OEM，MOQ 100"
  },
  "confirmed_company": {
    "official_name": "Example Pumps Sp. z o.o.",
    "official_domain": "https://www.example.com/",
    "country": "Poland",
    "identity_basis": "官网 Contact 地址与公司注册页一致"
  },
  "web_evidence": [],
  "browser_evidence": {
    "source_url": "https://www.example.com/team",
    "captured_at": "2026-08-27",
    "status": "public_page_verified",
    "page_attempts": ["/team", "/contact"],
    "failure_reason": "",
    "raw_items": [
      {
        "company_name": "Example Pumps Sp. z o.o.",
        "company_domain": "example.com",
        "full_name": "Jane Doe",
        "job_title": "Procurement Manager",
        "email": "jane.doe@example.com",
        "linkedin": "https://www.linkedin.com/in/example",
        "source_url": "https://www.example.com/team"
      }
    ]
  },
  "structured_report": {},
  "risks": [],
  "action_plan": []
}
```

`browser_evidence.raw_items` 不是浏览器内部数据，而是从公开页面人工归一化后的公司与职业联系人字段；每条最好带 `source_url`。没有联系人时传空数组，不制造占位人物。

## 12. 生成 Excel

运行：

```bash
python3 "$SKILL_ROOT/scripts/build_report_xlsx.py" \
  --input "$WORKSPACE_ROOT/company_background_input.json" \
  --output "$WORKSPACE_ROOT/YYYY-MM-DD_公司名_公司背调报告.xlsx"
```

路径约定：

```bash
SKILL_ROOT="$SKILL_INSTALL_PATH"
WORKSPACE_ROOT="$PWD"
```

`SKILL_INSTALL_PATH` 必须来自读取 `$company-background-check-xlsx` 时返回的 `install_path`，不能硬编码开发机路径。

脚本必须：生成三个可见 Sheet；生成 `.log`；重开 Excel；运行 ZIP 包结构校验；检查工作表名、公式、表格/绘图关系和可读性。依赖缺失时不得静默安装，先说明影响并取得确认。

## 13. 交付前验收

调用 `delivery-quality-check` 并逐项确认：

- 正确主体与官网已确认，或歧义已明确；
- 十章节齐全，缺失项没有被删除；
- 关键结论带来源和访问日期；
- 公司级数据与国家/行业数据没有混写；
- 联系人均为公开职业信息且有来源；
- 三个 Sheet 名称、顺序和内容正确；
- Excel 可重开，日志和安全校验通过；
- 最终回复说明未核验页面、冲突来源和未执行动作。

## 14. 失败与降级

- Search 不可用：不能可靠识别主体，停止并说明。
- Fetch 不可用：可继续 Search + Browser Relay，但所有正文证据需明确来源与降级。
- Browser Relay 不可用：继续 Search + Fetch，动态页面标记未复核。
- 同名主体无法消歧：向用户展示候选差异并等待确认，不自行选择。
- 官网无法访问：用权威外部来源做有限报告，明确“官网未回读”。
- 没有公开联系人：保留官网表单、企业邮箱、电话和公司职业页，不猜邮箱。
- 高风险负面信息只有单一弱来源：写入“待核验”，不得下定论。

最终回复包括：确认的公司主体、Excel 路径、主要结论、关键缺口、浏览器复核状态和验收结果。
