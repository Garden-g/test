# 启动

启动后确认私有 Skill `jigong-image-generation-guide` 及任务所需的卖点、细节或场景参考文件可读取，并等待用户给出业务目标。
