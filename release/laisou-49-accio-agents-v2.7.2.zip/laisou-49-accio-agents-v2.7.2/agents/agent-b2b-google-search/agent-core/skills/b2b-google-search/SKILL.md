---
name: b2b-google-search
displayName: "谷歌搜索找客户"
displayDescription: "用 Search、Fetch 与 Accio Browser Relay 查海外客户官网候选并导出可核验结果"
description: 使用 Accio 的 web_search、web_fetch 和 browser，从公开搜索结果中寻找海外 B2B 客户官网、进口商、批发商、分销商、品牌方与零售商，并导出带来源的 CSV/JSON。Use when the user asks to find overseas buyers or company websites through ordinary public web search.
---

# 谷歌搜索找客户

把“产品 + 客户类型 + 国家/地区”转换成一批可复核的海外公司候选。该技能只走公开网页路线：先 Search 建立候选池，再 Fetch 核验官网正文，最后用 Accio Browser Relay 检查动态页面或 Fetch 无法稳定读取的页面。不得调用第三方批量抓取服务，不绕过登录、验证码、访问限制或站点规则。

## 1. 工具契约

| 顺序 | 工具 | 责任 |
| --- | --- | --- |
| 1 | `ask_user` | 一次性补齐产品、客户类型、地区、数量与排除项 |
| 2 | `web_search` | 执行普通公开搜索，建立候选 URL 池 |
| 3 | `web_fetch` | 读取官网、About、Products、Contact、Store/Dealer 等公开页面 |
| 4 | `browser` | Accio Browser Relay 的运行时白名单标识；打开和查看动态页面、搜索落地页或 Fetch 无法读取的公开内容 |
| 5 | `write` / `present_files` | 生成并交付 CSV；用户要求保留结构化中间数据时同时生成 JSON |

`browser` 是本安装包中对 Accio Browser Relay 的能力声明。如果目标环境把浏览器能力拆成 `browser_*` 原子工具，只调用当时真实存在、语义相符的打开、导航、读取、点击分页或关闭标签页能力，不猜工具名。

浏览器默认只读。登录、授权、验证码、发送消息、提交表单、下载未知文件或改变外部状态时必须停止；本任务不需要登录即可完成公开搜索。不得让用户提供 Cookie、Token、密码或浏览器内部凭据。

## 2. 输入门禁

只补问会改变搜索范围的缺失项，并尽量一次问完：

1. 产品或类目，以及常见英文名、技术名或应用名；
2. 客户类型，例如 importer、wholesaler、distributor、brand、retailer；
3. 目标国家、地区或城市；
4. 期望数量，未指定时先交付 20 家高相关候选；
5. 排除项，例如现有客户、平台页、中国供应商、纯零售终端或特定竞品。

若产品过宽，先让用户在 2–3 个可执行细分方向中确认；若用户要求“越多越好”，先说明公开搜索的质量会随规模下降，按小批量验证后再扩展。

## 3. 搜索词设计

围绕一个业务目标生成 8–12 条互补查询，不把同一句只换大小写。基础模板：

```text
"{product}" {customer_type} {country}
"{product}" {customer_type_synonym} {country}
intitle:"{customer_type}" "{product}" {country}
"{product}" "authorized distributor" {country}
"{product}" "wholesale" {country} contact
"{product}" {country} "about us"
```

默认排除高噪声平台与供应商目录：

```text
-alibaba -amazon -made-in-china -aliexpress -ebay -dhgate -globalsources
```

客户类型常用同义词：

| 目标类型 | 可扩展词 |
| --- | --- |
| importer | import company, importing company, import agent, sourcing company |
| wholesaler | wholesale company, bulk supplier, wholesale distributor |
| distributor | authorized distributor, regional distributor, dealer network |
| brand | brand owner, private label brand, product company |
| retailer | retail chain, specialty retailer, online retailer |

优先使用目标市场语言；非英语国家可用英语与当地语言各一组。搜索词中出现城市时，要保留国家，避免同名城市误匹配。

## 4. Search：建立候选池

用 `web_search` 分批执行查询。每个结果至少记录：

- 搜索词；
- 标题与摘要；
- 结果 URL；
- 初步公司名；
- 国家、产品与客户类型线索；
- 搜索时间；
- 是否疑似平台、目录、新闻、社媒或独立官网。

Search 结果只是候选，不等于已确认公司。以下结果直接降级或剔除：

- marketplace、黄页、聚合目录、职位页、PDF 下载页；
- 只有同名词但产品、国家或公司主体不匹配；
- 明显为制造商供应端，而用户要求的是买家端；
- 无法定位到独立公司主体的单篇帖子或新闻；
- 重定向、仿冒站、异常域名或明显失效站点。

候选不足时依次扩展：客户类型同义词 → 应用行业词 → 城市/州/省 → 当地语言；不要直接取消全部质量过滤。

## 5. Fetch：确认官网与业务匹配

对高价值候选优先 Fetch：

1. 官网首页；
2. About / Company / Who We Are；
3. Products / Brands / Categories；
4. Contact / Locations / Store Locator / Dealer；
5. 可证明分销、批发、进口或品牌关系的公开页面。

至少用两个维度确认主体：公司名与域名、地址与国家、产品与业务描述、官网与权威外部来源。官网打不开时，保留搜索摘要但标记“官网未回读”，不得把摘要内容升级成已确认事实。

每家公司提取：公司名、根域名、国家/地址、客户类型证据、产品匹配、公开企业邮箱/电话、联系表单、社媒链接、采购或分销线索、来源 URL、页面日期或访问日期、待确认项。

## 6. Accio Browser Relay：动态页面复核

仅在以下情况调用 `browser`：

- Search 返回的是动态搜索落地页，需要确认真实跳转 URL；
- Fetch 只能得到空壳、脚本页或拒绝正文，但页面仍可公开查看；
- 需要查看公开页面上可见的导航、公司名称、地址、联系方式或分页；
- 同名公司冲突，需要在页面视觉信息中确认 Logo、地区或业务范围。

操作顺序：打开 URL → 等待页面稳定 → 读取当前页标题和关键可见字段 → 必要时只点击与当前证据直接相关的公开导航或下一页 → 记录最终 URL 与访问时间 → 关闭无关标签页。

若出现登录墙、验证码、异常跳转、访问频控或无法读取的嵌入内容，立即停止该页面并标记原因；改用其他公开来源，不反复刷新、不模拟人类规避限制。

## 7. 去重与证据分级

去重优先级：根域名 > 明确公司主体名 + 国家 > 电话 > 地址。集团、地区子公司和经销门店不能静默合并；主体不同则保留不同记录并说明关系。

| 证据等级 | 判定 |
| --- | --- |
| A | 官网正文同时确认公司、产品/业务和目标地区 |
| B | 官网确认主体，权威目录或社媒补充客户类型/联系方式 |
| C | 只有搜索摘要或单一第三方页面，需人工复核 |
| 排除 | 主体、国家、产品或客户类型明显不匹配 |

评分建议（100 分）：产品匹配 25、客户类型匹配 20、国家匹配 15、官网主体确认 15、联系方式 10、采购/分销线索 10、来源新鲜度 5。无法确认的项不给分。

## 8. 交付字段与文件

默认 CSV 字段：

```text
priority,score,company_name,country,customer_type,website,product_match,
customer_type_evidence,emails,phones,contact_page,social_links,
procurement_or_distribution_clues,source_urls,evidence_level,accessed_at,
risk_or_pending,search_query
```

JSON 与 CSV 必须来自同一份规范化记录。多值字段在 CSV 中用 ` | ` 分隔；任何以 `= + - @` 开头的单元格文本前加单引号，避免表格公式注入。不得编造邮箱、联系人、进口记录、采购量、营收或公司规模。

交付前调用 `delivery-quality-check`：重新读取文件，核对列数、编码、重复公司、空值标记、来源 URL、数量、评分范围和公式注入防护。只有真实文件存在且回读通过后，才能说“已完成”。

## 9. 失败与降级

- Search 不可用：说明当前无法建立候选池，不用 Browser Relay 假装完成批量搜索。
- Fetch 不可用：可以交付 Search 候选，但全部标记“正文未核验”，并降低证据等级。
- Browser Relay 不可用：继续完成 Search + Fetch 路线；动态页面标记“未做浏览器复核”。
- 结果少于目标：交付真实数量、已用搜索词和不足原因，不用低质量页面凑数。
- 用户要求自动联系：本 Skill 只产出名单，不发送邮件、私信或表单；应先让用户审阅名单，再转交合适的触达流程。

最终回复只说明：实际找到并通过哪一级核验的数量、文件路径、主要缺口、未执行动作和下一步建议。
