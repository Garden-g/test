---
name: b2b-facebook-search
displayName: "脸书主页找客户"
displayDescription: "用 Search、Fetch 与 Accio Browser Relay 查海外企业公开主页和业务联系线索"
description: 使用 Accio 的 web_search、web_fetch 和 browser，从 Facebook 公开企业主页、主页外链与公司官网中寻找海外品牌、商家、批发商、分销商和零售商，导出带来源的 B2B CSV/JSON。
---

# Facebook 主页找客户

本技能只处理公开企业页和公开业务信息。Search 负责从普通搜索引擎找到主页候选，Fetch 负责核验主页外链和公司官网，Accio Browser Relay 负责查看动态主页中公开可见的企业信息。不得使用第三方批量抓取平台，不把个人账号、私人联系方式、群组成员或帖子互动用户当作默认采集对象。

## 1. 工具契约

| 顺序 | 工具 | 责任 |
| --- | --- | --- |
| 1 | `ask_user` | 确认产品、客户类型、地区、数量、排除项 |
| 2 | `web_search` | 用公开搜索找到 Facebook 企业页及关联官网 |
| 3 | `web_fetch` | 读取可抓取的公开页面、主页外链、官网和 Contact 页面 |
| 4 | `browser` | Accio Browser Relay 白名单标识；查看动态企业主页的公开可见字段 |
| 5 | `write` / `present_files` | 生成 CSV；用户要求时同时保留规范化 JSON |

若目标环境只暴露 `browser_*` 原子工具，按真实工具列表调用打开、导航、读取和关闭标签页能力，不猜测名称。浏览器默认只读：不得登录、关注、点赞、评论、发私信、加入群组、提交表单或绕过验证码。

## 2. 输入门禁

一次性确认：

1. 产品或类目；
2. 客户类型，例如 importer、wholesaler、distributor、brand、retailer；
3. 国家、地区或城市；
4. 目标数量；未指定时先交付 20 个高相关企业页；
5. 是否必须有独立官网、企业邮箱或电话；
6. 需要排除的群组、个人页、媒体页、纯内容创作者、现有客户或中国供应商。

用户要求私人手机号、私人邮箱、群组成员名单或大规模个人画像时，拒绝该部分并继续提供最少必要的企业公开字段。

## 3. 搜索词设计

优先用普通搜索引擎索引公开企业页：

```text
site:facebook.com "{product}" "{country}" "{customer_type}"
site:facebook.com/pages "{product}" "{country}" wholesale
site:facebook.com "{product}" "{city}" distributor
site:facebook.com "{product}" "{country}" official
"{company_or_product}" Facebook {country}
```

默认排除个人、群组和内容噪声：

```text
-groups -posts -events -marketplace -watch -reel -people -profile -share -login
```

再追加通用平台与供应商噪声排除词。非英语国家同时使用当地语言的行业词、批发/经销词和城市名。

## 4. Search：建立主页候选池

每个候选至少记录：搜索词、结果标题、摘要、Facebook URL、可能的企业名、地区线索、产品线索、客户类型线索、主页类型判断和搜索日期。

优先保留：

- 标题或摘要明确表示公司、品牌、商家、门店、批发商、分销商；
- 页面指向独立官网或显示公开业务联系路径；
- 产品、地区和目标客户类型至少有两项匹配；
- 主页近期仍有公开业务活动迹象，但不能仅凭发帖频率推断采购意向。

剔除：

- 个人 profile、粉丝社区、群组、活动、Marketplace、单篇帖子、Reel/Watch；
- 同名但国家或行业不符的主页；
- 无法确认企业主体、只有转载内容的页面；
- 明显失效、冒充、诈骗或异常跳转页面。

Search 摘要不等于主页当前内容。粉丝量、电话、邮箱、地址、营业时间等字段必须由主页可见内容或官网二次确认。

## 5. Fetch：核验外链官网

优先 Fetch：

1. 搜索结果可直接读取的公开主页；
2. 主页外链官网；
3. 官网首页、About、Products/Brands、Contact、Locations；
4. 权威行业目录或公司注册信息页面。

提取公司名、根域名、国家/地址、产品类别、客户类型证据、公开企业邮箱/电话、联系表单、其他企业社媒、批发/分销/品牌经营线索、来源 URL 和访问日期。

Facebook URL 与官网主体不一致时，不要自动合并；分别记录并标记“外链主体待确认”。Fetch 被页面脚本或访问限制阻断时，转到 Browser Relay 做公开可见复核。

## 6. Accio Browser Relay：动态主页复核

仅在以下情况调用 `browser`：

- 公开主页是动态页面，Fetch 没有正文；
- 需要确认页面类型是企业页而非个人页/群组；
- 需要读取公开可见的企业名、类别、About、地址、电话、网站按钮或当前 URL；
- 搜索结果存在同名主页，需要用地区、Logo、简介和官网外链区分。

操作顺序：打开主页 → 等待公开内容稳定 → 读取页名、类型、简介、地区、联系按钮和外链 → 必要时打开外链官网并交给 Fetch → 记录最终 URL 与访问时间 → 关闭标签。

遇到登录墙、验证码、内容仅对登录用户可见、频控或地区限制时立即停止。不得让用户提供账号凭据，不反复刷新，不把不可见内容写成已核验。若公开页只能显示名称和 URL，就只记录这两项。

## 7. 主体确认与证据分级

至少满足以下两项才把主页标为已确认企业：

- 主页名称与官网公司名一致；
- 主页地区/地址与目标市场一致；
- 主页产品/简介与官网业务一致；
- 官网明确链接回该 Facebook 页；
- 公开电话、域名邮箱或品牌标识能对应同一主体。

| 等级 | 含义 |
| --- | --- |
| A | Facebook 企业页与官网互相印证，产品和地区匹配 |
| B | 企业页主体明确，只有一个权威外部来源补充 |
| C | 仅有 Search 摘要或公开页字段过少，需要人工复核 |
| 排除 | 个人页、群组、主体错配、国家/产品不符 |

去重优先级：官网根域名 > 规范化 Facebook 主页 URL > 企业名 + 国家 > 企业电话。品牌总部和地区经销商不能静默合并。

## 8. 评分

| 维度 | 分值 |
| --- | --- |
| 产品匹配 | 25 |
| 客户类型匹配 | 20 |
| 地区匹配 | 15 |
| 企业主体确认 | 15 |
| 官网与业务联系方式 | 10 |
| 批发/分销/品牌线索 | 10 |
| 页面当前可访问与来源新鲜度 | 5 |

`A`：80 分及以上；`B`：60–79；`C`：40–59；明显错配或低于 40 排除。不能根据粉丝量直接推断公司规模、营收、采购能力或合作意愿。

## 9. 交付字段

默认 CSV 字段：

```text
priority,score,company_name,country,customer_type,facebook_url,page_type,
website,public_business_emails,public_business_phones,address,
product_match,customer_type_evidence,activity_note,other_social_links,
source_urls,evidence_level,accessed_at,risk_or_pending,search_query
```

只交付公开企业联系方式。私人邮箱、私人手机号、个人住址和无关个人资料默认删除。多值字段用 ` | ` 分隔；防止表格公式注入；缺失字段写 `未找到可靠公开信息`。

交付前调用 `delivery-quality-check` 回读 CSV/JSON，检查：是否混入个人页/群组、重复主页、错配官网、私人数据、无来源字段、公式注入风险、数量和编码。检查失败不得宣称完成。

## 10. 失败与降级

- Search 不可用：停止建立候选池，不以浏览器零散浏览冒充批量搜索。
- Fetch 不可用：官网内容全部降级，仅保留可见主页证据。
- Browser Relay 不可用：仍可交付 Search + Fetch 结果；动态主页标记未复核。
- 页面要求登录或验证码：停止该页并换公开来源。
- 结果不足：交付真实数量、已用搜索词与不足原因，不用个人页凑数。
- 用户要求自动私信：本 Skill 不发送消息，只生成名单和可选触达建议。

最终回报真实候选数、A/B/C 数量、文件路径、主页受限数量、未核验字段与下一步人工抽检建议。
