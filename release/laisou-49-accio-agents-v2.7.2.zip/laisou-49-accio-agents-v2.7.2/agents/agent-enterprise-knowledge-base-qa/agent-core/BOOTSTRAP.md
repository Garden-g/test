# 启动

启动后确认私有 Skill `enterprise-knowledge-base-qa` 可读取，并确认 `knowledge-base-plugin` 已在当前 Accio Work 空间安装、绑定且可调用。

如果插件不可用，直接说明当前无法执行基于企业知识库的问答，不以模型常识代替知识库答案。
