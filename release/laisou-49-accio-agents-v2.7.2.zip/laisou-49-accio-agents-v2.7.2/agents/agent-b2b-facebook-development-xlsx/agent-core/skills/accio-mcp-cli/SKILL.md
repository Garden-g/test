---
name: accio-mcp-cli
description: Use the accio-mcp-cli command-line tool to discover, search, and invoke MCP tools from the terminal when the user asks to use MCP integrations, call a connected service through CLI, inspect available MCP capabilities, or when an enabled plugin needs an MCP tool that is not already exposed in the current tool list. Prefer toolkit, then search, then call; do not assume that tool availability proves authorization or entitlement.
---

# Accio MCP CLI

`accio-mcp-cli --help` is authoritative. Commands and flags can change between releases, so check the installed CLI before relying on this reference.

## Resolve the launcher first

Prefer the short command when it is on `PATH`:

```bash
command -v accio-mcp-cli
accio-mcp-cli --help
```

On macOS, Accio may bundle the CLI without exposing a shell command. If the first check returns nothing, verify and invoke the packaged entrypoint:

```bash
test -f "/Applications/Accio.app/Contents/Resources/accio-mcp-cli/accio-mcp.mjs"
node "/Applications/Accio.app/Contents/Resources/accio-mcp-cli/accio-mcp.mjs" --help
```

Use the same resolved launcher for later `toolkit`, `search`, and `call` commands. Do not create a global symlink or modify shell startup files unless the user explicitly requests that system-level change.

## Default workflow

Use `toolkit` -> `search` -> `call`. Avoid starting with `list`, because a large tool catalog wastes context.

```bash
accio-mcp-cli toolkit gmail
accio-mcp-cli search twitter
accio-mcp-cli call <tool> --arg value
```

## Commands

| Command | Purpose |
|---|---|
| `search <keyword>` | Search tool names, descriptions, and toolkits |
| `toolkit [keyword]` | Browse toolkits or filter by toolkit name |
| `call <name> [--arg value]` | Invoke a tool; use `--json '{...}'` for structured arguments |
| `list` | List all tools; use only when broad output is genuinely needed |
| `server list` | Inspect custom MCP servers and status |
| `server test <name>` | Test a custom server connection |
| `server tools <name>` | List tools from one custom server |
| `server add --json '{...}'` | Add a custom server; requires explicit user authorization |
| `server remove <name>` | Remove a custom server; requires explicit user authorization |
| `server auth <name>` | Start authorization; requires explicit user authorization |

Call argument rules: `--json '{...}'` takes precedence; `--key value` becomes a named argument; a standalone `--flag` becomes `true`. Use `--raw` when exact JSON output matters and `--refresh` only when a stale cache is suspected.

## Safety and authorization

- Discovery and read-only inspection may proceed when they are relevant to the user's task.
- Ask for explicit confirmation before adding or removing servers, opening an authorization flow, or invoking tools that send, publish, edit, delete, purchase, spend quota, or change external state.
- Never print tokens, credentials, authorization codes, or sensitive connector configuration.
- Tool discovery proves only that a capability is advertised. Verify authorization, account scope, entitlement, and the actual call result separately.
- Preserve the specialist agent's task scope. MCP availability does not authorize unrelated actions.

## Troubleshooting

| Problem | Action |
|---|---|
| Cannot connect | Confirm Accio Desktop is running, then inspect `accio-mcp-cli --help` |
| 401 Unauthorized | Restart Accio Desktop and retry only the read-only check |
| Tool not found | Use `search <keyword>` instead of guessing the name |
| Version mismatch | Follow `accio-mcp-cli --help` or the relevant subcommand help |
| Slow tool | Use `--raw` when useful and keep the running process observable |
