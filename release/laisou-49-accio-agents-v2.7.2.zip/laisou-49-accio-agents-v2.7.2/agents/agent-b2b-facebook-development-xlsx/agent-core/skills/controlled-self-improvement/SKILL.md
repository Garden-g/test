---
name: controlled-self-improvement
description: Use after the user corrects the agent, an operation fails, a delivered result exposes a reusable quality problem, or a completed task yields a durable working lesson. Record only a concise, sanitized lesson for later reuse. Do not trigger for hypothetical advice, one-off preferences, raw customer facts, or ordinary task notes, and never silently rewrite the agent's identity or core instructions.
---

# Controlled Self-Improvement

Turn real corrections and failures into small, reusable lessons without letting incidental task content rewrite the agent.

## When to use

Use this skill only when at least one of these has actually happened:

- The user explicitly corrected the agent's behavior, assumption, format, or result.
- A command, tool call, file operation, or delivery failed and the failure suggests a reusable prevention rule.
- A completed task revealed a stable workflow improvement that is likely to matter again.

Do not use it for hypothetical discussion, casual feedback, a single customer's facts, temporary task instructions, or information already covered by the current core files.

## Workflow

1. Identify the concrete event: what happened, what evidence showed the problem, and what changed.
2. Separate a reusable lesson from task-specific details.
3. Remove secrets, credentials, personal data, customer names, contact lists, raw reports, attachments, and commercially sensitive details.
4. Check the current `AGENTS.md` and memory rules before writing anything.
5. Append one concise entry to `diary/YYYY-MM-DD.md` only when the current rules allow it. Create the date file if needed; do not replace existing entries.
6. If the lesson may deserve long-term promotion, label it as a candidate. Do not edit `IDENTITY.md`, `SOUL.md`, `AGENTS.md`, `TOOLS.md`, or other core files automatically. Let the existing memory-return protocol and explicit user confirmation control any promotion.

## Entry format

```markdown
## HH:MM - Short lesson title

- Trigger: the correction, failure, or verified observation
- Lesson: one reusable rule stated without customer-specific detail
- Next time: the concrete behavior to apply
- Evidence: the file, command, or result that supported the lesson, when safe to record
- Promotion: no | candidate pending confirmation
```

## Quality rules

- Prefer one precise lesson over a long retrospective.
- Record verified facts separately from inference.
- Never claim a lesson was saved unless the write succeeded and was read back.
- Do not promote a preference merely because it appeared once.
- Do not turn a local workaround into a universal rule without evidence.
- If the core instructions conflict with the proposed lesson, follow the core instructions and report the conflict instead of writing.

