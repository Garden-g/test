---
name: delivery-quality-check
description: Use immediately before claiming that a requested deliverable is complete, or when the user asks to verify an existing deliverable. Check the real output by reopening or re-reading it, validate the expected content and format, disclose anything not verified, and block a false completion claim. Applies to files, reports, tables, presentations, documents, PDFs, images, and structured business results; it does not replace the specialist creation skill for each file type.
---

# Delivery Quality Check

Verify the actual result before calling it delivered.

## Workflow

1. Restate the expected deliverable and its acceptance conditions from the current task.
2. Confirm the real output exists at the claimed location and has the expected file type or response structure.
3. Reopen, re-read, or re-query the output through an independent read path whenever possible.
4. Validate the points that matter for this output:
   - required sections, fields, rows, pages, files, or links are present;
   - facts, calculations, formulas, references, and source attribution are internally consistent;
   - empty, placeholder, truncated, duplicated, or obviously stale content is absent;
   - formatting and visual layout are usable when a render or preview is available;
   - sensitive information, unintended external writes, and unsupported claims are absent;
   - the result still follows the specialist agent's business rules and the user's requested scope.
5. For `.xlsx`, `.docx`, `.pdf`, or `.pptx`, use the corresponding enabled file plugin's own validation workflow. This skill coordinates the final gate; it does not duplicate or override those specialist instructions.
6. If a check fails, do not say the work is complete. Fix it when the fix is safe and authorized; otherwise report the exact failed check and what remains unverified.
7. Report the delivered path or result, the checks that passed, and any explicit limitation.

## Minimum evidence by output type

| Output | Minimum evidence before completion |
|---|---|
| File | Exists, opens or parses, expected size/content is present |
| Table or Excel | Required sheets/columns/rows exist; formulas and references are checked; workbook reopens |
| Document or PDF | Expected sections/pages exist; text can be extracted or visually inspected |
| Presentation | Slide count and required pages match; deck opens; key layouts are visually checked |
| Analysis or report | Inputs and assumptions are stated; important conclusions trace back to evidence |
| External action | Success receipt or returned identifier exists; side effects match the approved scope |

## Guardrails

- Never treat “command exited successfully” as sufficient proof by itself.
- Never invent a successful visual, network, account, or permission check.
- A plugin being enabled does not prove its service is authorized or entitled.
- Do not broaden the task while checking it.
- When only static validation was possible, say so plainly.

