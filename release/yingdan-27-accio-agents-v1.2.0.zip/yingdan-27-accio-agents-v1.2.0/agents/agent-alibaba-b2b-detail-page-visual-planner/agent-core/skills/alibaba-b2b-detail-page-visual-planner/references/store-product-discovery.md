# 店铺商品智能发现

当用户只说“做标题、详情页或卖点”，没有点名产品、商品 ID、图片或链接时，先读取店铺真实类目和商品，再让用户点选。不要第一句话就问“你是什么产品”。

## 可用只读工具

| 目的 | MCP 工具 | Workctl 等价命令 | 说明 |
| --- | --- | --- | --- |
| 读取已有商品类目 | `queryCustomerGoodsCateSummary` | `workctl icbu ads list-customer-goods-cate-summary` | 返回店铺实际商品的 1-3 级类目，优先使用。 |
| 读取店铺语境 | `findCustomerShopInfo` | `workctl icbu ads search-customer-shop` | 返回主营行业、橱窗商品和近期高关联词，用于排序和命名选项。 |
| 读取或筛选商品 | `list_products` | `workctl icbu product list` | 可按当前 schema 使用商品 ID、商品名或空查询读取商品。 |
| 按名称检索 | `list_products_by_name` | `workctl icbu product list-name` | 用户或选择项只给商品名时使用。 |
| 读取单品详情 | `list_products_by_id` | `workctl icbu product list-id` | 读取已选商品的标题、属性、主图和类目。 |
| 批量读取商品详情 | `queryGoodsInfoByGoodsIdList` | `workctl icbu ads list-goods-goods-id-list` | 已有多个商品 ID 时使用。 |
| 读取可发布类目 | `query_user_category` | `workctl icbu product list-user-category` | 只表示账号可经营/发布类目，不能冒充店铺已有商品；仅作兜底。 |

调用前必须查看当前运行环境中的真实 schema。直接 MCP、Workctl 和 `accio-mcp-cli` 的参数包装可能不同，不要把一种 transport 的 JSON 结构硬套到另一种。Workctl 必须先通过版本、认证和缓存就绪检查；`accio-mcp-cli` 必须在 Accio 管理的 Gateway 环境中按 `search -> call` 使用。任何一层未认证或不可用时，换用当前可用的只读层，不得提取或复用 Gateway token。

## 默认流程

1. 用户已经给出明确商品 ID、产品名、图片或链接时，跳过全店扫描，直接解析该产品。
2. 用户未指定产品时，并行读取已有商品类目和店铺语境；优先展示真实已有商品类目，不展示只有发布权限但没有商品的类目。
3. 用 `ask_user` 展示 2-4 个类目选项。类目超过 4 个时，展示最相关的 3 个和“查看更多类目”，不要一次塞完整列表。
4. 用户选择类目后，读取商品列表并按返回的类目字段筛选；优先展示橱窗商品、近期有询盘/流量的商品或信息更完整的商品，但不得把排序解释成质量保证。
5. 用 `ask_user` 展示 2-4 个商品选项，每项包含可读产品名和商品 ID。候选过多时展示 3 个和“搜索其他商品”。
6. 用户选中商品后，调用 `list_products_by_id`；多选时调用批量详情工具。后续优先使用后台返回的标题、属性、主图和类目，只补问仍然缺失且会改变结果的事实。
7. 类目工具成功但商品列表没有返回时，可以先让用户选择类目，再按名称检索；不得把“未返回”写成“店铺没有商品”。
8. 所有发现工具都不可用、未认证或无结果时，明确说明没有读取到店铺数据，再退回让用户输入产品名、商品 ID、图片或链接。

整个发现流程只读。不得因为完成选品就自动编辑商品、生成图片、消耗额度或发布页面。
