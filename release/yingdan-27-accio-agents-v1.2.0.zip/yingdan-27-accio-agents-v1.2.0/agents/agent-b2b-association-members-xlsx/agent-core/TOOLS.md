# Tools

工具列表由 Accio Work 根据 `tool-registry.jsonc` 在运行时注入。

<!-- TOOL_LIST -->