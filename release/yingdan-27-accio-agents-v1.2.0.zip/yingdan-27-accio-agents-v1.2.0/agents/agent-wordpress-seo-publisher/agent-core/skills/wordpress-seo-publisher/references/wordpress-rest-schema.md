# WordPress REST Schema Notes

These notes document the real WordPress and Yoast interfaces that were confirmed against the target environment.

## Confirmed Authentication Check

Use:

```text
GET /wp-json/wp/v2/users/me?context=edit
```

Expected capabilities include:

- `edit_posts`
- `publish_posts`
- `upload_files`
- `edit_pages`
- `publish_pages`
- `manage_options`

## Confirmed Post Endpoint

Use:

```text
POST /wp-json/wp/v2/posts
```

Confirmed writable fields:

- `date`
- `date_gmt`
- `slug`
- `status`
- `password`
- `title`
- `content`
- `author`
- `excerpt`
- `featured_media`
- `comment_status`
- `ping_status`
- `format`
- `meta`
- `sticky`
- `template`
- `categories`
- `tags`

## Confirmed Media Endpoint

Use:

```text
POST /wp-json/wp/v2/media
```

Confirmed writable fields:

- `date`
- `date_gmt`
- `slug`
- `status`
- `title`
- `author`
- `featured_media`
- `comment_status`
- `ping_status`
- `meta`
- `template`
- `alt_text`
- `caption`
- `description`
- `post`

## Confirmed Category Endpoint

Use:

```text
GET /wp-json/wp/v2/categories?per_page=100
POST /wp-json/wp/v2/categories
```

The `GET` endpoint should be called before publishing so the skill can reuse an
existing relevant category instead of creating duplicates or falling back to
`Uncategorized` / `未分类`.

Confirmed writable fields:

- `description`
- `name`
- `slug`
- `parent`
- `meta`

## Confirmed Tag Endpoint

Use:

```text
POST /wp-json/wp/v2/tags
```

Confirmed writable fields:

- `description`
- `name`
- `slug`
- `meta`

## Confirmed Yoast Verification Endpoint

Use:

```text
GET /wp-json/yoast/v1/get_head?url={post_url}
```

This endpoint returns Yoast-generated HTML and JSON fields for validation after creating the draft.

## Confirmed Yoast Meta Keys Exposed On Posts

These keys were confirmed in the `meta` properties of the posts schema:

- `_yoast_wpseo_title`
- `_yoast_wpseo_metadesc`
- `_yoast_wpseo_focuskw`
- `_yoast_wpseo_canonical`
- `_yoast_wpseo_opengraph-title`
- `_yoast_wpseo_opengraph-description`
- `_yoast_wpseo_twitter-title`
- `_yoast_wpseo_twitter-description`
