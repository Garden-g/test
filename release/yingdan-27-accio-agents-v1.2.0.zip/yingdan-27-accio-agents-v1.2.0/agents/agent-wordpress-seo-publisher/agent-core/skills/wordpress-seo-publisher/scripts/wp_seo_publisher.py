#!/usr/bin/env python3
"""WordPress SEO Publisher helper script.

This script wraps the deterministic WordPress and Yoast REST operations needed by
the `wordpress-seo-publisher` skill. The skill itself should own the user
conversation, content generation, and image tool sequencing. This script should
own the repeatable API work so each invocation behaves predictably.
"""

from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


# These fields are the minimum company and publishing details the skill needs in
# order to write content that matches the company and safely connect to
# WordPress. If any of them are missing, the skill should stop and ask for setup
# help instead of guessing.
REQUIRED_PROFILE_FIELDS = {
    "company name",
    "website",
    "wordpress domain",
    "wordpress username",
    "core products/services",
    "customer types",
    "primary countries/regions",
    "tone",
    "top strengths",
    "preferred internal pages to link to",
    "preferred visual style",
}

# These Yoast keys were confirmed in the target site's post schema. The script
# checks them directly so the calling skill can stop early when the site has not
# exposed Yoast meta to REST.
REQUIRED_YOAST_META_KEYS = [
    "_yoast_wpseo_title",
    "_yoast_wpseo_metadesc",
    "_yoast_wpseo_focuskw",
    "_yoast_wpseo_canonical",
    "_yoast_wpseo_opengraph-title",
    "_yoast_wpseo_opengraph-description",
    "_yoast_wpseo_twitter-title",
    "_yoast_wpseo_twitter-description",
]


@dataclass
class WPConfig:
    """Simple runtime configuration for WordPress access.

    Args:
        domain: Base WordPress site URL, such as ``https://example.com``.
        username: WordPress username used for Basic Auth.
        password: WordPress application password value.
        password_env_var: Environment variable name the password came from.

    Returns:
        An immutable config container for REST calls.

    Raises:
        ValueError: If required values are missing or malformed.
    """

    domain: str
    username: str
    password: str
    password_env_var: str

    def __post_init__(self) -> None:
        """Validate the config after creation.

        Args:
            None.

        Returns:
            None.

        Raises:
            ValueError: If the domain, username, or password are blank.
        """

        self.domain = self.domain.rstrip("/")
        if not self.domain.startswith(("http://", "https://")):
            raise ValueError("WordPress domain must start with http:// or https://")
        if not self.username.strip():
            raise ValueError("WordPress username is required")
        if not self.password.strip():
            raise ValueError("WordPress application password is required")


class MissingProfileFieldError(KeyError):
    """Raised when a required field is missing from ``USER.md``.

    Args:
        field_name: The normalized field name that could not be resolved.

    Returns:
        None.

    Raises:
        None.
    """

    def __init__(self, field_name: str) -> None:
        """Store the missing field name and a human-readable message.

        Args:
            field_name: The normalized field name that is missing.

        Returns:
            None.

        Raises:
            None.
        """

        super().__init__(field_name)
        self.field_name = field_name

    def __str__(self) -> str:
        """Format a user-friendly error message.

        Args:
            None.

        Returns:
            A readable message explaining which profile field is missing.

        Raises:
            None.
        """

        return f"USER.md is missing required field: {self.field_name}"


def print_json(data: Dict[str, Any]) -> None:
    """Print stable JSON to stdout for the calling skill.

    Args:
        data: A JSON-serializable dictionary to emit.

    Returns:
        None.

    Raises:
        TypeError: If the value cannot be serialized to JSON.
    """

    print(json.dumps(data, ensure_ascii=False, indent=2))


def slugify(value: str) -> str:
    """Turn human text into a WordPress-friendly slug.

    Args:
        value: The human-readable string to normalize.

    Returns:
        A lowercase hyphenated slug.

    Raises:
        None.
    """

    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")


def looks_missing(value: str) -> bool:
    """Decide whether a Markdown field is effectively empty.

    The template intentionally uses placeholders such as ``待补充``. Treating
    those values as missing allows the skill to guide the user instead of
    writing content from fake defaults.

    Args:
        value: A field value extracted from ``USER.md``.

    Returns:
        True when the value is empty or clearly a placeholder.

    Raises:
        None.
    """

    normalized = value.strip().lower()
    missing_markers = {
        "",
        "待补充",
        "todo",
        "tbd",
        "unknown",
        "n/a",
        "none",
    }
    return normalized in missing_markers or normalized.startswith("todo_")


def parse_user_md(user_md_path: Path) -> Dict[str, Any]:
    """Parse the skill-local ``USER.md`` into a structured dictionary.

    The parser is intentionally simple and only supports the template style used
    by this skill: Markdown headings plus bullet lines in ``Key: Value`` format.

    Args:
        user_md_path: Path to the Markdown company profile file.

    Returns:
        A dictionary with section names, flattened fields, and raw lines.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the file cannot be decoded as UTF-8 text.
    """

    content = user_md_path.read_text(encoding="utf-8")
    sections: Dict[str, Dict[str, str]] = {}
    flat_fields: Dict[str, str] = {}
    current_section = "root"
    sections[current_section] = {}

    for raw_line in content.splitlines():
        line = raw_line.strip()
        if line.startswith("## "):
            current_section = line[3:].strip()
            sections.setdefault(current_section, {})
            continue
        match = re.match(r"[-*]\s+([^:]+):\s*(.*)$", line)
        if not match:
            continue
        key = match.group(1).strip()
        value = match.group(2).strip()
        key_normalized = key.lower()
        sections.setdefault(current_section, {})[key] = value
        flat_fields[key_normalized] = value

    return {
        "path": str(user_md_path),
        "sections": sections,
        "fields": flat_fields,
    }


def require_profile_field(profile: Dict[str, Any], field_name: str) -> str:
    """Fetch a required field from the parsed company profile.

    Args:
        profile: Parsed ``USER.md`` data from :func:`parse_user_md`.
        field_name: Lowercase field name to retrieve.

    Returns:
        The field value when present and not a placeholder.

    Raises:
        KeyError: If the field is missing or still a placeholder.
    """

    value = profile["fields"].get(field_name, "")
    if looks_missing(value):
        raise MissingProfileFieldError(field_name)
    return value


def build_wp_config(profile: Dict[str, Any], password_env_override: Optional[str]) -> WPConfig:
    """Create a :class:`WPConfig` from ``USER.md`` and the environment.

    Args:
        profile: Parsed company profile dictionary.
        password_env_override: Optional CLI override for the password env var.

    Returns:
        A validated :class:`WPConfig`.

    Raises:
        KeyError: If the required profile fields are missing.
        EnvironmentError: If the application password environment variable is not set.
        ValueError: If the final WordPress config is malformed.
    """

    domain = require_profile_field(profile, "wordpress domain")
    username = require_profile_field(profile, "wordpress username")
    env_var = password_env_override or profile["fields"].get(
        "application password env var",
        "WORDPRESS_APPLICATION_PASSWORD",
    )
    env_var = env_var.strip() or "WORDPRESS_APPLICATION_PASSWORD"
    password = os.getenv(env_var, "").replace(" ", "")
    if not password:
        raise EnvironmentError(
            f"WordPress application password environment variable '{env_var}' is not set"
        )
    return WPConfig(domain=domain, username=username, password=password, password_env_var=env_var)


def basic_auth_header(config: WPConfig) -> str:
    """Build the HTTP Basic Auth header for WordPress REST calls.

    Args:
        config: Valid WordPress runtime configuration.

    Returns:
        A Basic Auth header value.

    Raises:
        UnicodeEncodeError: If credentials cannot be encoded, which is unlikely.
    """

    token = base64.b64encode(f"{config.username}:{config.password}".encode("utf-8")).decode("ascii")
    return f"Basic {token}"


def wp_request(
    config: WPConfig,
    path: str,
    *,
    method: str = "GET",
    query: Optional[Dict[str, Any]] = None,
    json_body: Optional[Dict[str, Any]] = None,
    raw_body: Optional[bytes] = None,
    extra_headers: Optional[Dict[str, str]] = None,
) -> Tuple[int, Any]:
    """Send a REST request to WordPress and parse the JSON response when possible.

    Args:
        config: Valid WordPress runtime configuration.
        path: REST path beginning with ``/wp-json/``.
        method: HTTP method to use.
        query: Optional query string parameters.
        json_body: Optional JSON payload for POST/PATCH requests.
        raw_body: Optional raw bytes payload, mainly for media upload.
        extra_headers: Optional extra HTTP headers.

    Returns:
        A tuple of ``(status_code, decoded_body)``.

    Raises:
        urllib.error.URLError: If the network request fails before a response exists.
    """

    url = f"{config.domain}{path}"
    if query:
        query_string = urllib.parse.urlencode(query, doseq=True)
        url = f"{url}?{query_string}"

    headers = {
        "Accept": "application/json",
        "Authorization": basic_auth_header(config),
        "User-Agent": "wordpress-seo-publisher/1.0",
    }
    if extra_headers:
        headers.update(extra_headers)

    body = raw_body
    if json_body is not None:
        body = json.dumps(json_body).encode("utf-8")
        headers["Content-Type"] = "application/json"

    request = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            payload_bytes = response.read()
            content_type = response.headers.get("Content-Type", "")
            if "json" in content_type:
                return response.status, json.loads(payload_bytes.decode("utf-8"))
            return response.status, payload_bytes.decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        payload_bytes = exc.read()
        content_type = exc.headers.get("Content-Type", "")
        if "json" in content_type:
            return exc.code, json.loads(payload_bytes.decode("utf-8"))
        return exc.code, payload_bytes.decode("utf-8", errors="replace")


def command_check_user_profile(args: argparse.Namespace) -> Dict[str, Any]:
    """Validate that ``USER.md`` has enough information for the skill.

    Args:
        args: Parsed CLI arguments with ``user_md``.

    Returns:
        A JSON-serializable result dictionary with missing fields and summary.

    Raises:
        FileNotFoundError: If ``USER.md`` does not exist.
    """

    profile = parse_user_md(Path(args.user_md))
    missing_fields = [
        field for field in sorted(REQUIRED_PROFILE_FIELDS) if looks_missing(profile["fields"].get(field, ""))
    ]
    summary = {
        key: profile["fields"].get(key, "")
        for key in [
            "company name",
            "website",
            "wordpress domain",
            "wordpress username",
            "core products/services",
            "customer types",
            "primary countries/regions",
            "tone",
        ]
    }
    return {
        "ok": not missing_fields,
        "message": "Company profile is ready" if not missing_fields else "Company profile is missing required fields",
        "missing_fields": missing_fields,
        "profile_summary": summary,
    }


def command_check_wp_setup(args: argparse.Namespace) -> Dict[str, Any]:
    """Check WordPress authentication and high-level publishing capability.

    Args:
        args: Parsed CLI arguments with ``user_md`` and optional env override.

    Returns:
        A JSON-serializable result dictionary with user role and capabilities.

    Raises:
        FileNotFoundError: If ``USER.md`` does not exist.
        EnvironmentError: If the password env var is missing.
    """

    profile = parse_user_md(Path(args.user_md))
    config = build_wp_config(profile, args.password_env)
    root_status, root_data = wp_request(config, "/wp-json/")
    me_status, me_data = wp_request(config, "/wp-json/wp/v2/users/me", query={"context": "edit"})

    capabilities = {}
    if isinstance(me_data, dict) and isinstance(me_data.get("capabilities"), dict):
        capabilities = {
            key: me_data["capabilities"].get(key)
            for key in [
                "edit_posts",
                "publish_posts",
                "upload_files",
                "edit_pages",
                "publish_pages",
                "manage_options",
            ]
        }

    ok = (
        root_status == 200
        and me_status == 200
        and capabilities.get("publish_posts")
        and capabilities.get("upload_files")
    )
    return {
        "ok": bool(ok),
        "message": "WordPress setup is ready" if ok else "WordPress setup is incomplete",
        "domain": config.domain,
        "username": config.username,
        "password_env_var": config.password_env_var,
        "root_status": root_status,
        "auth_status": me_status,
        "user_id": me_data.get("id") if isinstance(me_data, dict) else None,
        "roles": me_data.get("roles") if isinstance(me_data, dict) else [],
        "capabilities": capabilities,
    }


def command_check_yoast_meta(args: argparse.Namespace) -> Dict[str, Any]:
    """Check whether the target site exposes Yoast post meta through REST.

    Args:
        args: Parsed CLI arguments with ``user_md`` and optional env override.

    Returns:
        A JSON-serializable result dictionary with visible and missing meta keys.

    Raises:
        FileNotFoundError: If ``USER.md`` does not exist.
        EnvironmentError: If the password env var is missing.
    """

    profile = parse_user_md(Path(args.user_md))
    config = build_wp_config(profile, args.password_env)
    status, data = wp_request(config, "/wp-json/wp/v2/posts", method="OPTIONS")
    meta_properties = (
        data.get("schema", {})
        .get("properties", {})
        .get("meta", {})
        .get("properties", {})
        if isinstance(data, dict)
        else {}
    )
    visible_keys = sorted(meta_properties.keys()) if isinstance(meta_properties, dict) else []
    missing_keys = [key for key in REQUIRED_YOAST_META_KEYS if key not in visible_keys]
    return {
        "ok": status == 200 and not missing_keys,
        "message": "Yoast meta is writable through REST" if not missing_keys else "Yoast meta is not fully exposed through REST",
        "status": status,
        "visible_yoast_meta_keys": [key for key in visible_keys if key.startswith("_yoast_wpseo_")],
        "missing_yoast_meta_keys": missing_keys,
    }


def command_list_categories(args: argparse.Namespace) -> Dict[str, Any]:
    """List existing WordPress categories for conservative taxonomy selection.

    The skill should choose an existing relevant category before it creates a
    new one. This command deliberately does not make that semantic decision; it
    only returns the current site categories in a small, stable shape that is
    easy for a weaker model or workflow tool to inspect.

    Args:
        args: Parsed CLI arguments with ``user_md`` and optional env override.

    Returns:
        A JSON-serializable result with ``id``, ``name``, ``slug``, ``count``,
        and ``parent`` for each category.

    Raises:
        FileNotFoundError: If ``USER.md`` does not exist.
        EnvironmentError: If the password env var is missing.
    """

    profile = parse_user_md(Path(args.user_md))
    config = build_wp_config(profile, args.password_env)
    status, data = wp_request(
        config,
        "/wp-json/wp/v2/categories",
        query={
            "per_page": 100,
            "orderby": "name",
            "order": "asc",
        },
    )
    if status != 200 or not isinstance(data, list):
        return {
            "ok": False,
            "message": "Failed to list WordPress categories",
            "status": status,
            "categories": [],
            "error": data if not isinstance(data, dict) else data.get("message"),
        }

    categories = [
        {
            "id": item.get("id"),
            "name": item.get("name"),
            "slug": item.get("slug"),
            "count": item.get("count"),
            "parent": item.get("parent"),
        }
        for item in data
        if isinstance(item, dict)
    ]
    return {
        "ok": True,
        "message": "Listed WordPress categories",
        "categories": categories,
    }


def find_existing_term(config: WPConfig, taxonomy: str, name: str, slug: Optional[str]) -> Optional[Dict[str, Any]]:
    """Look up an existing category or tag before creating a duplicate.

    Args:
        config: WordPress runtime configuration.
        taxonomy: Either ``categories`` or ``tags``.
        name: Human-readable taxonomy name.
        slug: Optional explicit slug to check.

    Returns:
        The first matching taxonomy object, or ``None`` when not found.

    Raises:
        urllib.error.URLError: If the underlying REST request fails.
    """

    query: Dict[str, Any] = {"per_page": 100, "search": name}
    if slug:
        query["slug"] = slug
    status, data = wp_request(config, f"/wp-json/wp/v2/{taxonomy}", query=query)
    if status != 200 or not isinstance(data, list):
        return None
    normalized_name = name.strip().lower()
    normalized_slug = slugify(slug or name)
    for item in data:
        item_name = str(item.get("name", "")).strip().lower()
        item_slug = str(item.get("slug", "")).strip().lower()
        if item_name == normalized_name or item_slug == normalized_slug:
            return item
    return None


def ensure_term(config: WPConfig, taxonomy: str, name: str, slug: Optional[str], description: str = "", parent: Optional[int] = None) -> Dict[str, Any]:
    """Create or reuse a category or tag.

    Args:
        config: WordPress runtime configuration.
        taxonomy: Either ``categories`` or ``tags``.
        name: Human-readable taxonomy name.
        slug: Optional slug override.
        description: Optional term description.
        parent: Optional parent category id for nested categories.

    Returns:
        A JSON-serializable result dictionary describing the term.

    Raises:
        ValueError: If the taxonomy name is unsupported.
    """

    if taxonomy not in {"categories", "tags"}:
        raise ValueError("taxonomy must be 'categories' or 'tags'")

    existing = find_existing_term(config, taxonomy, name=name, slug=slug)
    if existing:
        return {
            "ok": True,
            "message": f"Reused existing {taxonomy[:-1]}",
            "created": False,
            "term": existing,
        }

    payload: Dict[str, Any] = {
        "name": name,
        "slug": slugify(slug or name),
        "description": description,
    }
    if taxonomy == "categories" and parent is not None:
        payload["parent"] = parent

    status, data = wp_request(config, f"/wp-json/wp/v2/{taxonomy}", method="POST", json_body=payload)
    return {
        "ok": status in {200, 201},
        "message": f"Created new {taxonomy[:-1]}" if status in {200, 201} else f"Failed to create {taxonomy[:-1]}",
        "created": status in {200, 201},
        "term": data if isinstance(data, dict) else None,
        "status": status,
        "error": data if not isinstance(data, dict) else data.get("message"),
    }


def command_ensure_category(args: argparse.Namespace) -> Dict[str, Any]:
    """CLI wrapper for category reuse or creation.

    Args:
        args: Parsed CLI arguments with term details.

    Returns:
        A JSON-serializable category result.

    Raises:
        FileNotFoundError: If ``USER.md`` does not exist.
        EnvironmentError: If the password env var is missing.
    """

    profile = parse_user_md(Path(args.user_md))
    config = build_wp_config(profile, args.password_env)
    return ensure_term(
        config,
        "categories",
        name=args.name,
        slug=args.slug,
        description=args.description or "",
        parent=args.parent,
    )


def command_ensure_tag(args: argparse.Namespace) -> Dict[str, Any]:
    """CLI wrapper for tag reuse or creation.

    Args:
        args: Parsed CLI arguments with term details.

    Returns:
        A JSON-serializable tag result.

    Raises:
        FileNotFoundError: If ``USER.md`` does not exist.
        EnvironmentError: If the password env var is missing.
    """

    profile = parse_user_md(Path(args.user_md))
    config = build_wp_config(profile, args.password_env)
    return ensure_term(
        config,
        "tags",
        name=args.name,
        slug=args.slug,
        description=args.description or "",
    )


def command_upload_media(args: argparse.Namespace) -> Dict[str, Any]:
    """Upload a media file and patch its SEO-friendly helper fields.

    Args:
        args: Parsed CLI arguments with the file path and media metadata.

    Returns:
        A JSON-serializable result containing the media id and URLs.

    Raises:
        FileNotFoundError: If the media file does not exist.
        EnvironmentError: If the password env var is missing.
    """

    file_path = Path(args.file)
    if not file_path.exists():
        raise FileNotFoundError(f"Media file does not exist: {file_path}")

    profile = parse_user_md(Path(args.user_md))
    config = build_wp_config(profile, args.password_env)

    raw_bytes = file_path.read_bytes()
    mime_type = mimetypes.guess_type(str(file_path))[0] or "application/octet-stream"
    filename = file_path.name
    upload_headers = {
        "Content-Disposition": f'attachment; filename="{filename}"',
        "Content-Type": mime_type,
    }
    upload_status, upload_data = wp_request(
        config,
        "/wp-json/wp/v2/media",
        method="POST",
        raw_body=raw_bytes,
        extra_headers=upload_headers,
    )
    if upload_status not in {200, 201} or not isinstance(upload_data, dict):
        return {
            "ok": False,
            "message": "Media upload failed",
            "status": upload_status,
            "error": upload_data if not isinstance(upload_data, dict) else upload_data.get("message"),
        }

    media_id = int(upload_data["id"])
    patch_payload: Dict[str, Any] = {}
    if args.title:
        patch_payload["title"] = args.title
    if args.slug:
        patch_payload["slug"] = slugify(args.slug)
    if args.alt_text:
        patch_payload["alt_text"] = args.alt_text
    if args.caption:
        patch_payload["caption"] = args.caption
    if args.description:
        patch_payload["description"] = args.description
    if args.post_id is not None:
        patch_payload["post"] = args.post_id

    patch_status = None
    patch_data: Any = None
    if patch_payload:
        patch_status, patch_data = wp_request(
            config,
            f"/wp-json/wp/v2/media/{media_id}",
            method="POST",
            json_body=patch_payload,
        )

    final_media = patch_data if isinstance(patch_data, dict) else upload_data
    return {
        "ok": True,
        "message": "Media uploaded successfully",
        "media_id": media_id,
        "status": upload_status,
        "patch_status": patch_status,
        "link": final_media.get("link"),
        "source_url": final_media.get("source_url") or upload_data.get("source_url"),
    }


def load_payload_json(payload_path: Path) -> Dict[str, Any]:
    """Load a JSON payload file for create-draft commands.

    Args:
        payload_path: Path to a JSON file.

    Returns:
        The decoded JSON object.

    Raises:
        FileNotFoundError: If the file does not exist.
        json.JSONDecodeError: If the file is not valid JSON.
        ValueError: If the top-level JSON value is not an object.
    """

    data = json.loads(payload_path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Payload JSON must be an object")
    return data


def extract_title_text(title_value: Any) -> str:
    """Normalize a WordPress title payload into plain text.

    Args:
        title_value: A string title or WordPress title object.

    Returns:
        The best plain-text title value available.

    Raises:
        None.
    """

    if isinstance(title_value, dict):
        raw = title_value.get("raw") or title_value.get("rendered") or ""
        return str(raw).strip()
    return str(title_value or "").strip()


def normalize_post_body(payload: Dict[str, Any]) -> List[str]:
    """Apply safe WordPress body cleanup before creating a post.

    WordPress themes normally render the post title as the page H1. When the
    generated body also starts with the same H1, the public page shows two big
    titles. This cleanup removes a leading duplicate H1 while leaving the rest
    of the content untouched.

    Args:
        payload: The mutable post payload that will be sent to WordPress.

    Returns:
        A list of cleanup notes for the command output.

    Raises:
        None.
    """

    notes: List[str] = []
    content = payload.get("content")
    if not isinstance(content, str) or "<h1" not in content.lower():
        return notes

    title_text = extract_title_text(payload.get("title"))
    leading_h1 = re.match(r"^\s*<h1\b[^>]*>(.*?)</h1>\s*", content, flags=re.IGNORECASE | re.DOTALL)
    if not leading_h1:
        notes.append("Content contains an H1 outside the leading position; review body formatting.")
        return notes

    h1_text = re.sub(r"<[^>]+>", "", leading_h1.group(1)).strip()
    if title_text and h1_text.lower() == title_text.lower():
        payload["content"] = content[leading_h1.end() :]
        notes.append("Removed duplicate leading H1 from content body because WordPress renders the post title.")
    else:
        payload["content"] = re.sub(r"^\s*<h1\b([^>]*)>", r"<h2\1>", content, count=1, flags=re.IGNORECASE)
        payload["content"] = re.sub(r"</h1>\s*", "</h2>", payload["content"], count=1, flags=re.IGNORECASE)
        notes.append("Converted leading H1 in content body to H2 because WordPress renders the post title.")
    return notes


def validate_post_categories(payload: Dict[str, Any]) -> Optional[str]:
    """Confirm that a post payload carries at least one category id.

    WordPress silently falls back to the site's default category when the
    ``categories`` field is missing. On this site that can appear publicly as
    ``Uncategorized`` or ``未分类``. The helper rejects that situation before
    making the REST call, so the calling skill must explicitly choose or create
    a category first.

    Args:
        payload: The post payload that would be sent to WordPress.

    Returns:
        ``None`` when the payload has at least one usable category id; otherwise
        a human-readable reason explaining why post creation is blocked.

    Raises:
        None.
    """

    categories = payload.get("categories")
    if not isinstance(categories, list) or not categories:
        return (
            "Post payload must include a non-empty categories list. "
            "Run list_categories first, then reuse an existing category or call ensure_category."
        )

    usable_category_ids: List[int] = []
    for category in categories:
        try:
            category_id = int(category)
        except (TypeError, ValueError):
            continue
        if category_id > 0:
            usable_category_ids.append(category_id)

    if not usable_category_ids:
        return (
            "Post payload categories must contain at least one positive category id. "
            "Run list_categories first, then reuse an existing category or call ensure_category."
        )
    return None


def command_create_draft_post(args: argparse.Namespace) -> Dict[str, Any]:
    """Create a WordPress post, defaulting safely to ``draft``.

    Args:
        args: Parsed CLI arguments including the payload JSON path.

    Returns:
        A JSON-serializable result dictionary describing the created post.

    Raises:
        FileNotFoundError: If the payload file does not exist.
        EnvironmentError: If the password env var is missing.
    """

    profile = parse_user_md(Path(args.user_md))
    config = build_wp_config(profile, args.password_env)
    payload = load_payload_json(Path(args.payload))

    # A safe default matters here because the skill should not accidentally
    # publish public content unless the human explicitly asked for that.
    payload.setdefault("status", "draft")
    category_error = validate_post_categories(payload)
    if category_error:
        return {
            "ok": False,
            "message": "Post creation blocked because no valid category was provided",
            "error": category_error,
            "category_ids": [],
        }

    cleanup_notes = normalize_post_body(payload)
    status, data = wp_request(config, "/wp-json/wp/v2/posts", method="POST", json_body=payload)
    if status not in {200, 201} or not isinstance(data, dict):
        return {
            "ok": False,
            "message": "Post creation failed",
            "status": status,
            "error": data if not isinstance(data, dict) else data.get("message"),
        }

    post_id = data.get("id")
    link = data.get("link")
    edit_link = None
    if post_id is not None:
        edit_link = f"{config.domain}/wp-admin/post.php?post={post_id}&action=edit"

    return {
        "ok": True,
        "message": "Post created successfully",
        "post_id": post_id,
        "status": data.get("status"),
        "link": link,
        "edit_link": edit_link,
        "category_ids": data.get("categories", []),
        "tag_ids": data.get("tags", []),
        "featured_media": data.get("featured_media"),
        "cleanup_notes": cleanup_notes,
    }


def command_verify_yoast_output(args: argparse.Namespace) -> Dict[str, Any]:
    """Verify Yoast-generated output for a post URL.

    Args:
        args: Parsed CLI arguments with ``url`` or ``post_id``.

    Returns:
        A JSON-serializable result dictionary with Yoast validation details.

    Raises:
        ValueError: If neither a URL nor a post id is provided.
        EnvironmentError: If the password env var is missing.
    """

    profile = parse_user_md(Path(args.user_md))
    config = build_wp_config(profile, args.password_env)

    post_url = args.url
    post_status_value: Optional[str] = None
    post_meta: Dict[str, Any] = {}
    if args.post_id is not None:
        post_status, post_data = wp_request(
            config,
            f"/wp-json/wp/v2/posts/{args.post_id}",
            query={"context": "edit"},
        )
        if post_status == 200 and isinstance(post_data, dict):
            post_url = post_url or post_data.get("link")
            post_status_value = post_data.get("status")
            if isinstance(post_data.get("meta"), dict):
                post_meta = post_data["meta"]
    if not post_url:
        raise ValueError("A post URL or post id is required for Yoast verification")

    status, data = wp_request(config, "/wp-json/yoast/v1/get_head", query={"url": post_url})
    if status != 200 or not isinstance(data, dict):
        return {
            "ok": False,
            "message": "Yoast verification failed",
            "status": status,
            "error": data if not isinstance(data, dict) else data.get("message"),
        }

    yoast_json = data.get("json", {})
    title = yoast_json.get("title") if isinstance(yoast_json, dict) else None
    description = yoast_json.get("description") if isinstance(yoast_json, dict) else None
    canonical = yoast_json.get("canonical") if isinstance(yoast_json, dict) else None
    og_title = yoast_json.get("og_title") if isinstance(yoast_json, dict) else None
    twitter_title = yoast_json.get("twitter_title") if isinstance(yoast_json, dict) else None
    has_schema = bool(yoast_json.get("schema")) if isinstance(yoast_json, dict) else False
    # Draft posts often do not expose final public Yoast output through get_head,
    # even when the post meta has been saved correctly. In that case, treat the
    # stored Yoast fields as the source of truth for a draft smoke test.
    if post_status_value == "draft":
        title = post_meta.get("_yoast_wpseo_title") or title
        description = post_meta.get("_yoast_wpseo_metadesc") or description
        canonical = post_meta.get("_yoast_wpseo_canonical") or canonical
        og_title = post_meta.get("_yoast_wpseo_opengraph-title") or og_title
        twitter_title = post_meta.get("_yoast_wpseo_twitter-title") or twitter_title
    ok = all([title, description, canonical])

    return {
        "ok": ok,
        "message": "Yoast verification passed" if ok else "Yoast verification returned incomplete SEO fields",
        "url": post_url,
        "post_status": post_status_value,
        "yoast_validation": {
            "title": title,
            "description": description,
            "canonical": canonical,
            "og_title": og_title,
            "twitter_title": twitter_title,
            "has_schema": has_schema,
        },
    }


def build_parser() -> argparse.ArgumentParser:
    """Create the CLI parser for all supported helper commands.

    Args:
        None.

    Returns:
        A fully configured :class:`argparse.ArgumentParser`.

    Raises:
        None.
    """

    parser = argparse.ArgumentParser(description="WordPress SEO Publisher helper script")
    subparsers = parser.add_subparsers(dest="command", required=True)

    def add_common_arguments(subparser: argparse.ArgumentParser) -> None:
        """Attach arguments shared by most commands.

        Args:
            subparser: The subparser to modify.

        Returns:
            None.

        Raises:
            None.
        """

        subparser.add_argument("--user-md", required=True, help="Path to the skill-local USER.md file")
        subparser.add_argument(
            "--password-env",
            default=None,
            help="Optional override for the application password environment variable name",
        )

    check_user_profile = subparsers.add_parser("check_user_profile", help="Validate USER.md completeness")
    check_user_profile.add_argument("--user-md", required=True, help="Path to the skill-local USER.md file")
    check_user_profile.set_defaults(handler=command_check_user_profile)

    check_wp_setup = subparsers.add_parser("check_wp_setup", help="Check WordPress authentication and permissions")
    add_common_arguments(check_wp_setup)
    check_wp_setup.set_defaults(handler=command_check_wp_setup)

    check_yoast_meta = subparsers.add_parser("check_yoast_meta", help="Check Yoast REST meta availability")
    add_common_arguments(check_yoast_meta)
    check_yoast_meta.set_defaults(handler=command_check_yoast_meta)

    list_categories = subparsers.add_parser("list_categories", help="List existing WordPress categories")
    add_common_arguments(list_categories)
    list_categories.set_defaults(handler=command_list_categories)

    ensure_category = subparsers.add_parser("ensure_category", help="Create or reuse a category")
    add_common_arguments(ensure_category)
    ensure_category.add_argument("--name", required=True, help="Category name")
    ensure_category.add_argument("--slug", default=None, help="Optional category slug")
    ensure_category.add_argument("--description", default="", help="Optional category description")
    ensure_category.add_argument("--parent", type=int, default=None, help="Optional parent category id")
    ensure_category.set_defaults(handler=command_ensure_category)

    ensure_tag = subparsers.add_parser("ensure_tag", help="Create or reuse a tag")
    add_common_arguments(ensure_tag)
    ensure_tag.add_argument("--name", required=True, help="Tag name")
    ensure_tag.add_argument("--slug", default=None, help="Optional tag slug")
    ensure_tag.add_argument("--description", default="", help="Optional tag description")
    ensure_tag.set_defaults(handler=command_ensure_tag)

    upload_media = subparsers.add_parser("upload_media", help="Upload media and patch SEO helper fields")
    add_common_arguments(upload_media)
    upload_media.add_argument("--file", required=True, help="Local media file path")
    upload_media.add_argument("--title", default="", help="Optional media title")
    upload_media.add_argument("--slug", default="", help="Optional media slug")
    upload_media.add_argument("--alt-text", default="", help="Alt text for the image")
    upload_media.add_argument("--caption", default="", help="Image caption")
    upload_media.add_argument("--description", default="", help="Media description")
    upload_media.add_argument("--post-id", type=int, default=None, help="Optional post id to attach media to")
    upload_media.set_defaults(handler=command_upload_media)

    create_draft = subparsers.add_parser("create_draft_post", help="Create a draft post from a JSON payload")
    add_common_arguments(create_draft)
    create_draft.add_argument("--payload", required=True, help="Path to a JSON payload file")
    create_draft.set_defaults(handler=command_create_draft_post)

    verify_yoast = subparsers.add_parser("verify_yoast_output", help="Validate Yoast output for a post URL")
    add_common_arguments(verify_yoast)
    verify_yoast.add_argument("--url", default="", help="Published post URL to verify")
    verify_yoast.add_argument("--post-id", type=int, default=None, help="Optional post id when URL is unknown")
    verify_yoast.set_defaults(handler=command_verify_yoast_output)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    """CLI entry point.

    Args:
        argv: Optional argument list for testing. Uses ``sys.argv`` when omitted.

    Returns:
        Process exit code. ``0`` means success, ``1`` means failure.

    Raises:
        None. All user-facing exceptions are converted into structured JSON.
    """

    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        result = args.handler(args)
        print_json(result)
        return 0 if result.get("ok", False) else 1
    except Exception as exc:  # noqa: BLE001
        print_json(
            {
                "ok": False,
                "message": str(exc),
                "error_type": type(exc).__name__,
            }
        )
        return 1


if __name__ == "__main__":
    sys.exit(main())
