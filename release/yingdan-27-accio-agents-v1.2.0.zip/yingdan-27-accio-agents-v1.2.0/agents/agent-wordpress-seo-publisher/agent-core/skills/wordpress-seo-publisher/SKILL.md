---
name: wordpress-seo-publisher
displayName: "网站文章优化发布"
displayDescription: "生成并安全发布带分类图片和搜索优化字段的网站文章"
description: Use when the user wants to write, prepare, publish, or schedule a WordPress SEO blog, product blog, English B2B blog, Yoast SEO article, or automated WordPress post. Make sure to use this skill whenever the user mentions WordPress blog publishing, Yoast fields, English SEO content, product articles, publishing drafts, or turning company information into a blog post, even if they do not explicitly ask for a "skill" or "SEO workflow."
---

# WordPress SEO文章发布

Create English B2B SEO blog posts for WordPress, prepare the image plan, publish a draft, write Yoast SEO fields, and verify the result after publishing.

This skill is for small-business or non-technical users. Keep the intake simple. The user should not need to know what a slug, focus keyphrase, canonical URL, or REST API is unless it is necessary to unblock the workflow.

## What This Skill Owns

Use this skill when the user wants to:

- write a WordPress blog post
- publish an SEO blog to WordPress
- create an English product blog
- draft a Yoast-friendly article
- turn company information into a blog post
- generate a blog image plan and publish the post

This skill owns the full workflow:

1. Read the company profile from `USER.md`
2. Check whether WordPress publishing is initialized
3. Build an SEO brief
4. Generate the article structure and content
5. Generate the image plan
6. List existing WordPress categories and choose or create the primary category
7. Upload media and create a WordPress draft
8. Write Yoast SEO fields
9. Verify the published draft with Yoast

## Read These Files First

Before taking action, load these resources in this order:

1. `USER.md`
2. `references/prompts.md`
3. `references/blog-system-prompt.md` when writing a full long-form blog article
4. `references/seo-rules.md`
5. `references/wordpress-rest-schema.md`

Use `scripts/wp_seo_publisher.py` for deterministic WordPress actions instead of hand-building ad hoc REST requests in every run.

## Default Rules

- Default language is English.
- Default audience is B2B buyers, sourcing managers, wholesalers, importers, distributors, or brand teams.
- Default publish mode is `draft`.
- Only publish publicly when the user clearly says to publish now.
- Every article must have at least one featured image plan.
- Every image must include alt text, caption guidance, and filename guidance.
- The WordPress post title already renders as the page H1. Do not put another H1 inside the post body.
- Do not use random placeholder stock images for public posts. If a real generated or supplied image is unavailable, keep the post as a draft and report that the image still needs work.
- Use a lightweight article UI by default. The current Astra theme can make raw headings, tables, and bold text look heavy, so wrap generated content in a scoped article class and use softer typography rules when publishing HTML.
- Include at least one relevant internal link and one credible non-competitive external link when the topic allows it.
- Never print the WordPress application password back to the user.

## Two Initialization Checks

### 1. Company profile initialization

Read `USER.md` first.

If important company information is missing, ask short, plain-language questions and update the missing details in the final content plan. Treat these items as important:

- company name
- website
- WordPress domain
- WordPress username
- core products or services
- target customers
- target markets
- key advantages
- brand tone
- preferred internal links or CTA URLs
- image preferences

If `USER.md` is mostly empty, do not jump straight into writing a blog post. First gather enough company information so the article sounds like it belongs to the company.

### 2. WordPress publishing initialization

Run these checks through `scripts/wp_seo_publisher.py`:

- `check_user_profile`
- `check_wp_setup`
- `check_yoast_meta`

If WordPress publishing is not initialized, stop the publishing workflow and give the setup checklist below.

Setup checklist:

1. Confirm the WordPress site URL and username.
2. In WordPress, create an Application Password for this integration; store it in the environment variable expected by `scripts/wp_seo_publisher.py`, never in chat or `USER.md`.
3. Confirm the WordPress REST API accepts authenticated requests.
4. Install/enable Yoast SEO when Yoast fields are required.
5. Expose the required Yoast post meta fields to the REST API as described in `references/wordpress-rest-schema.md`, then rerun `check_yoast_meta`.

Missing setup includes any of these:

- missing WordPress domain
- missing WordPress username
- missing application password environment variable
- WordPress authentication failed
- Yoast SEO is unavailable
- Yoast post meta fields are not exposed to REST API

When setup is missing, explain the gap in business language. Do not dump raw stack traces or internal exceptions into the user-facing answer.

## Simple Intake

Keep the intake easy. Start with the user's topic and only ask more if it changes the article in a meaningful way.

Default intake order:

1. What topic or product should the post be about?
2. Is this post for draft only, or should it be published now?
3. If the topic is broad, ask who the article is for.

Do not force the user to fill a long SEO form. Generate the SEO packaging yourself.

## Content Workflow

## Confirmation Gate For WordPress Writes

Listing categories and validating authentication are read-only. Creating a category/tag, uploading media, creating/updating a post, changing Yoast fields, scheduling, or publishing changes WordPress. Immediately before the first write, show the site, proposed category/tag changes, media count, post title, intended status (`draft`/`future`/`publish`), and Yoast fields. Execute only after the user explicitly confirms that exact payload. A confirmation for a draft does not authorize public publishing.

### Step 1. Build the SEO brief

Use the company profile and the prompt templates in `references/prompts.md` to generate:

- primary keyword
- secondary keywords
- search intent
- target reader
- article angle
- recommended CTA

### Step 2. Build the SEO packaging

Generate:

- H1
- slug
- SEO title
- meta description
- focus keyphrase
- excerpt
- category suggestion
- tag suggestions

Follow the rules in `references/seo-rules.md`.

### Step 2.5. Choose the primary category

Always resolve category before creating the WordPress post.

Decision tree:

1. Run `list_categories` to fetch the site's existing categories.
2. If an existing category is relevant to the topic, use it.
3. If no exact match exists, use the closest broad existing category, such as a product, packaging, blog, industry, or guide category.
4. If the only available category is `Uncategorized` or `未分类`, create one reusable category such as `Custom Packaging`, `Packaging Tips`, or another stable category from `USER.md`.
5. If category creation fails, choose another existing non-default category if one exists.
6. If no valid category can be selected or created, do not silently publish as `Uncategorized` or `未分类`; report that category setup failed.

Category rules:

- Every WordPress SEO post should have exactly one primary category in the post payload unless the user asks for more.
- Do not leave `categories` empty.
- Do not use `Uncategorized` or `未分类` for public B2B SEO articles.
- Tags may be more specific, but categories should be broad and reusable.
- Before `create_draft_post`, make sure the payload includes `categories: [category_id]`.

### Step 3. Write the article

For a full long-form blog draft, use `references/blog-system-prompt.md` as the article-writing system prompt. Fill its company variables from `USER.md`, keep unknown company claims out of the article, and follow its required three-section output structure when the user asks for a complete publishable blog.

Write the blog post in English unless the user explicitly asks for another language.

Prefer practical B2B content:

- buyer pain points
- product or service use cases
- common procurement questions
- sourcing or production concerns
- FAQ
- next step or CTA

Write in WordPress-ready HTML or clean Markdown that can be converted to HTML.

Content body rules:

- Do not include `<h1>` or a Markdown `#` heading in the post body.
- Start the body with a short lead paragraph, then use H2/H3 sections.
- Prefer short paragraphs, bullet lists, comparison tables, FAQ blocks, and a clear CTA.
- Avoid one giant wall of text.
- Avoid large, dark, bold typography in the body. Keep H2/H3 useful but visually modest.
- Style tables lightly with smaller text, subtle borders, and normal-weight body cells.
- Put the focus keyphrase naturally into at least one H2 or H3.
- Add a relevant internal link, usually to the contact page, product page, or service page.
- Add one credible external link only when it helps the reader understand standards, market context, or best practice.
- Avoid decorative filler images and unrelated stock photography.
- If the theme already displays title, author, category, and featured image, let WordPress handle those elements instead of duplicating them in the body.

### Article visual template

When producing `content_html`, default to lightweight article HTML that still looks readable in a heavy WordPress theme.

Use this structure unless the user or theme provides a better template:

- Put all article body HTML inside `<div class="wp-seo-article">`.
- Add a short scoped `<style>` block before the wrapper when the site does not already provide a clean article layout.
- Scope every CSS selector to `.wp-seo-article` so the post does not change the global theme.
- Keep paragraph text normal-weight, medium gray, and comfortable to read.
- Keep H2/H3 headings modest: clear enough for scanning, but not huge or black-heavy.
- Style tables with subtle borders, normal-weight body cells, and enough padding.
- Format FAQ as separated cards or compact blocks, not as a dense wall of bold text.
- Use links naturally inside useful sentences. Do not add naked URLs or forced SEO links.

### Step 4. Create the image plan

Use natural-language tool instructions:

- use `image_generate` to create new blog images from prompts
- use `image_edit` when the image needs background, color, cleanup, or watermark changes
- use `see_image` when the user provides a local or remote image and you need to inspect it

For every image, generate:

- image purpose
- prompt
- filename suggestion
- alt text
- caption
- suggested placement in the article

Default image counts:

- 800-1200 words: 1 featured image
- 1200-1800 words: 1 featured image + 1 body image
- 1800+ words: 1 featured image + 2 body images

## Publishing Workflow

Use `scripts/wp_seo_publisher.py` for the publishing steps.

1. Run `list_categories`
2. Choose a relevant existing category or run `ensure_category`
3. Ensure tags
4. Upload the featured image
5. Create the post as a draft with `categories: [category_id]`
6. Write Yoast fields through the `meta` payload
7. Verify the post URL with Yoast

Required publish outputs:

- `post_id`
- `status`
- `link`
- `edit_link`
- `media_id`
- `category_ids`
- `tag_ids`
- `yoast_validation`

## Failure Handling

- If WordPress auth fails, stop and report that setup needs fixing.
- If Yoast fields are not writable, stop before publishing and point the user to the setup checklist in this skill.
- If image generation is unavailable, continue with the article and a detailed image plan instead of pretending the image exists.
- If the only available image is unrelated to the topic, do not upload it as the featured image. Continue as a draft with an image plan, or ask for/produce a relevant image first.
- If category selection or creation fails, do not create the post without a category; explain that category setup needs attention.
- If tag creation fails, explain it and continue only if the post can still be safely drafted with a valid category.
- If Yoast verification fails after draft creation, report the draft as created but mark SEO verification as incomplete.

## Final Response

When the workflow succeeds, tell the user:

- whether the post is a draft or published
- the main SEO angle
- the article URL and edit URL
- the featured image result or image plan status
- whether Yoast validation passed
- what still needs human review, if anything

If setup is missing, do not pretend the post was created. Clearly say publishing is blocked and point to the setup checklist in this skill.
