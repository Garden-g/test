# SEO Rules

These are the operating rules for the skill. Use them when generating or reviewing SEO fields.

## Slug

- Use lowercase letters.
- Use hyphens between words.
- Prefer 3-5 words when possible.
- Prefer 30-50 characters when possible.
- Include the primary keyword naturally.
- Do not include dates unless the topic truly depends on a year.
- Do not stuff multiple near-duplicate keywords into the slug.

## SEO Title

- Make it unique for the page.
- Put the main topic near the front when it helps readability.
- Prefer roughly 50-60 characters.
- Make it specific and useful instead of vague.
- Avoid boilerplate titles that only swap one word.
- Avoid keyword stuffing.

## Meta Description

- Make it unique for the page.
- Prefer roughly 140-160 characters.
- Summarize what the reader will get from the post.
- Include the main keyword naturally.
- A light CTA is good; ad-like hype is not.

## Focus Keyphrase

- Prefer 2-5 words.
- Choose a phrase a real buyer or researcher might search.
- Prefer commercial or informational B2B intent instead of vague single words.
- The phrase should appear naturally in:
  - the SEO title
  - the slug
  - the meta description
  - the introduction
  - at least one heading when it reads naturally

## Article Structure

- Start with a short introduction that tells the reader why the topic matters.
- Do not include an H1 inside the post body because WordPress already renders the post title as the page H1.
- Use clear H2 and H3 headings.
- Use short paragraphs, practical bullets, and tables when they make the article easier to scan.
- Keep body typography visually light. Avoid turning the whole article into oversized, black, heavy text.
- Use a scoped wrapper such as `.wp-seo-article` when the WordPress theme makes raw HTML look too heavy.
- Put the focus keyphrase naturally in at least one H2 or H3.
- Include at least one relevant internal link.
- Include one credible non-competitive external link when it adds reader value.
- Prefer practical information over empty promotional copy.
- Include FAQ when it helps capture search intent or buyer questions.
- End with a CTA that matches the company's real offering.

## Yoast Basics

- Include one internal link to a relevant company page, contact page, product page, or service page.
- Include one credible external link to a non-competitive reference when it helps the reader.
- Include the focus keyphrase in the SEO title, meta description, intro, and at least one subheading.
- Do not force links into irrelevant text just to satisfy a checklist.
- Prefer links embedded in helpful sentences over standalone "click here" links.
- For B2B articles, good external links are usually standards bodies, government resources, recognized industry organizations, or neutral educational references.
- If Yoast flags missing internal links, missing outbound links, or missing keyphrase in subheading, fix the article body before changing SEO metadata.

## Article UI Checks

- The published article should not look like a black, bold report page.
- Paragraphs should be comfortable to read on mobile and desktop, with normal font weight and enough line height.
- Tables should use light borders, modest font size, and clear spacing.
- FAQ should be visually separated into small blocks or cards.
- CTA should be visible but not loud, and should usually contain the main internal link.

## Taxonomy Rules

- Every WordPress SEO post must have one primary category before draft creation.
- Categories are for broad content archives; tags are for specific keywords and article details.
- Never allow a B2B SEO article to default to `Uncategorized` or `未分类`.
- Category priority is: existing relevant category, existing broad category, newly created reusable category, explicit failure report.
- If only `Uncategorized` or `未分类` exists, create a reusable category such as `Custom Packaging` or `Packaging Tips`.
- The post payload sent to WordPress must include `categories: [category_id]`.
- If the category cannot be selected or created, stop or clearly report that category setup failed instead of pretending the post is fully ready.

## Images

- Every post needs at least one featured image plan.
- Prefer realistic business visuals over decorative abstractions.
- The featured image must match the topic. A random landscape or unrelated stock photo is worse than no image.
- Use descriptive filenames.
- Use alt text that describes the visible scene.
- Do not stuff keywords into alt text.

## Image Count Defaults

- 800-1200 words: 1 featured image
- 1200-1800 words: 1 featured image + 1 body image
- 1800+ words: 1 featured image + 2 body images
