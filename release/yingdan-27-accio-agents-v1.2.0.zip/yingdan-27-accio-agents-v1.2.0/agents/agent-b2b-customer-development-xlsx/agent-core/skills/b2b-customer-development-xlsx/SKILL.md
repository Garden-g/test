---
name: b2b-customer-development-xlsx
displayName: "海外客户开发名单"
displayDescription: "按产品、客户类型和国家搜索客户并生成表格开发名单"
description: 客户开发 XLSX 技能。Use when the user wants to find overseas B2B buyers, importers, wholesalers, distributors, brands, retailers, or company website leads by product/category, customer type, and country/region, using Accio web_search, web_fetch, and ask_user, then export a verified Excel workbook for sales development.
---

# 客户开发 XLSX

把“产品 + 客户类型 + 国家/地区”变成一份可交付的客户开发 `.xlsx`。核心原则是：先把需求问清楚，再用公开网页证据找候选公司，最后只交付有来源、有空值标记、不编造的客户开发名单。

## 必填信息

如果用户没有一次性给全，先用 `ask_user` 一次性补齐，不要拆成多轮小问题：

```json
{
  "question": "请补充客户开发所需的三个条件。",
  "fields": [
    "要开发的产品或类目",
    "客户类型，例如 importer / wholesaler / distributor / brand / retailer",
    "目标国家或地区"
  ]
}
```

可选信息包括目标数量、排除客户、重点城市、最低公司规模、是否必须有邮箱。用户没有指定目标数量时，默认交付 50 家候选公司；最低目标是 30 家，除非公开结果确实不足。

## Tool Summary

| 步骤 | Use tool | 用途 |
| --- | --- | --- |
| 1 | `ask_user` | 补齐产品、客户类型、国家/地区，或在多个候选方向之间让用户确认 |
| 2 | `web_search` | 搜索潜在客户官网、目录页、社媒、进口/采购线索和行业来源 |
| 3 | `web_fetch` | 抓取官网、About、Contact、Products、Store Locator、社媒、目录页正文 |
| 4 | `scripts/build_customer_development_xlsx.py` | 把整理后的候选客户 JSON 渲染成安全 `.xlsx` |

`web_search` 示例入参形状：

```json
{
  "fieldName_3": {
    "payload": {
      "query": "\"pet supplies\" importer United States -alibaba -amazon -made-in-china",
      "api": "google"
    }
  }
}
```

`api` 优先使用 `google`。如果有效结果太少，再用同一批核心搜索词切换到 `you.com` 补充。

`web_fetch` 示例：

```json
{
  "urls": [
    "https://www.example.com/",
    "https://www.example.com/about",
    "https://www.example.com/contact"
  ],
  "timeout_seconds": 30
}
```

## 执行流程

### 1. 解析目标

从用户输入或 `ask_user` 返回中提取：

- `product`：产品或类目
- `customer_type`：客户类型，例如 importer、wholesaler、distributor、brand、retailer
- `country`：目标国家、地区或城市
- `target_count`：默认 50，最低目标 30

用中文复述目标，例如：“我会找美国宠物用品进口商，优先保留有官网、联系方式和产品匹配证据的公司。”

### 2. 生成搜索词

先生成 8 到 12 条搜索词。英语市场用英文；非英语市场可加当地语言客户类型词，但每批先小量验证。

基础模板：

```text
"{product}" "{customer_type}" "{country}"
"{product}" "{customer_type_synonym}" "{country}"
intitle:"{customer_type}" "{product}" "{country}"
"{product}" distributor list "{country}"
"{product}" wholesale supplier "{country}"
"{product}" retail chain "{country}"
"{product}" contact "{country}"
"{product}" import company "{country}"
```

默认排除平台和低质量噪声：

```text
-alibaba -amazon -made-in-china -aliexpress -ebay -walmart -dhgate -globalsources
```

客户类型同义词：

| 客户类型 | 英文同义词 |
| --- | --- |
| importer | import company, importing company, import agent, sourcing company |
| wholesaler | wholesale company, wholesale supplier, bulk supplier |
| distributor | distribution company, authorized distributor, regional distributor |
| brand | brand owner, private label brand, consumer brand |
| retailer | retail store, retail shop, retail chain, online store |

### 3. 用 web_search 找候选

每条搜索结果至少提取：

| 字段 | 说明 |
| --- | --- |
| 公司名 | 标题、摘要或网页里出现的公司名称 |
| URL | 结果链接 |
| 来源类型 | 官网、目录、社媒、新闻、进口数据、行业来源、其他 |
| 国家线索 | 摘要、页面、地址、域名或标题中的国家/地区证据 |
| 产品线索 | 摘要或标题中与产品相关的词 |
| 客户类型线索 | importer / wholesaler / distributor / brand / retailer 等证据 |

候选过滤规则：

- 优先保留独立官网，不要把 Alibaba、Amazon、Made-in-China、AliExpress、eBay、Walmart 等平台页当成客户官网。
- 去重 root domain；同一家公司多个页面合并到一条候选。
- LinkedIn、Facebook、Instagram、目录页可以作为证据，不替代官网。
- 如果国家、产品、客户类型都不匹配，丢弃。
- 如果保留候选少于 30 家，先用 `you.com` 补搜，再扩展客户类型同义词、城市/地区词、来源站点和相近渠道，优先把候选池扩到 30-50 家。

### 4. 用 web_fetch 抓取证据

对每个高价值候选优先抓取：

1. 官网首页
2. About / Company / Who we are
3. Contact / Locations / Offices
4. Products / Categories / Brands / Solutions
5. Store Locator / Dealers / Distributors
6. News / Blog / Case studies
7. LinkedIn、Facebook、Instagram、YouTube 等社媒主页
8. 可靠目录页、进口数据页、行业协会页或新闻来源

每家公司抽取：

| 字段 | 抽取要求 |
| --- | --- |
| 公司名 | 以官网或权威页面为准 |
| 官网 | 独立 root domain |
| 国家/地址 | 页面明确出现的地址、办公室或服务市场 |
| 客户类型 | 根据页面证据判断，不确定写“待确认” |
| 产品匹配点 | 页面明确展示的产品、品牌、类目、服务 |
| 联系方式 | 邮箱、电话、联系表单、社媒、地址 |
| 联系人 | 只记录公开出现的人名和职位 |
| 采购/进口线索 | import、sourcing、wholesale、distribution、dealer、brand portfolio 等公开证据 |
| 开发切入点 | 基于产品匹配和客户类型生成一句销售开发角度 |
| 风险/待确认 | 官网不可访问、信息过旧、国家不一致、只有目录页等 |
| 来源 URL | 每条关键判断必须带 URL |

缺失信息必须写 `未找到可靠公开信息`，不要编造邮箱、电话、联系人、进口记录、采购规模或公司背景。

### 5. 评分和优先级

按 100 分制评分。无法确认的项不给分，不用猜测补分：

| 维度 | 分值 |
| --- | --- |
| 产品匹配 | 0-25 |
| 客户类型匹配 | 0-20 |
| 国家/地区匹配 | 0-15 |
| 联系方式完整度 | 0-15 |
| 官网和公开证据可靠性 | 0-15 |
| 采购/进口/分销线索 | 0-10 |

优先级规则：

- `A`：80 分及以上，有官网、国家匹配、产品匹配、至少一种联系方式。
- `B`：60 到 79 分，方向匹配但联系方式或证据不完整。
- `C`：40 到 59 分，只能作为补充名单或待人工确认。
- `排除`：低于 40 分，或明显是平台页、同名错公司、国家不匹配。

### 6. 准备脚本输入 JSON

把研究结果整理成规范 JSON，再运行脚本。推荐结构：

```json
{
  "input": {
    "product": "pet supplies",
    "customer_type": "importer",
    "country": "United States",
    "target_count": 50
  },
  "leads": [
    {
      "priority": "A",
      "score": 86,
      "company_name": "Example Pet Imports",
      "country": "United States",
      "customer_type": "importer",
      "website": "https://www.example.com/",
      "emails": ["sales@example.com"],
      "phones": ["+1 000-000-0000"],
      "address": "Los Angeles, CA, United States",
      "contacts": [
        {
          "name": "Jane Smith",
          "title": "Purchasing Manager",
          "email": "jane@example.com",
          "linkedin": "https://www.linkedin.com/in/example"
        }
      ],
      "social_links": ["https://www.linkedin.com/company/example"],
      "product_match": "官网展示 pet toys、pet grooming supplies。",
      "procurement_import_clues": "Contact 页面提到 import and wholesale distribution。",
      "development_angle": "可从 OEM pet toys 和低 MOQ 补货切入。",
      "first_email_en": "Hi Jane, I noticed your pet supplies portfolio...",
      "source_urls": ["https://www.example.com/products", "https://www.example.com/contact"],
      "confidence": "高",
      "todo": "确认采购负责人邮箱是否仍有效。"
    }
  ],
  "company_profiles": [],
  "web_evidence": [],
  "search_records": [],
  "risks": [],
  "development_advice": []
}
```

运行：

```bash
python3 "$SKILL_ROOT/scripts/build_customer_development_xlsx.py" \
  --input "$WORKSPACE_ROOT/customer_development.json" \
  --output "$WORKSPACE_ROOT/customer_development.xlsx"
```

路径约定：

```bash
SKILL_ROOT="$SKILL_INSTALL_PATH"
WORKSPACE_ROOT="$PWD"
```

`SKILL_INSTALL_PATH` 使用读取 `$b2b-customer-development-xlsx` 时返回的 `install_path`；不要硬编码开发机路径。

### 7. 交付要求

交付前必须确认脚本成功完成：

- 生成 `.xlsx`
- 生成同名 `.log`
- LibreOffice headless 重存成功
- `unzip -t` 通过
- `openpyxl.load_workbook()` 通过
- 包内无非预期 `xl/tables/`、`xl/drawings/`、`tableParts`、drawing/table relationships

最终回复用户时说明：

- 文件路径
- 候选客户数量
- A/B/C 优先级数量
- 关键缺口，例如“有 8 家未找到邮箱，需要人工补充”
- 不要声称所有联系人都已验证；只说公开网页中找到了哪些证据
