---
name: b2b-google-maps
displayName: "谷歌地图找客户"
displayDescription: "用 Search、Fetch 与 Accio Browser Relay 核验海外实体商家、地址、电话和官网"
description: 使用 Accio 的 web_search、web_fetch 和 browser，从 Google Maps 公开页面、地图搜索结果与商家官网中寻找海外实体商家、批发商、分销商、门店、仓库、工厂和办公室线索，导出带来源的 CSV/JSON。
---

# 谷歌地图找客户

> **统一工具边界**
>
> 线索获取固定使用 Search（`web_search`）→ Fetch（`web_fetch`）→ Accio Browser Relay（`browser`）。Search 只建立候选池；Fetch 回读官网和公开正文；Browser Relay 只在动态页面或 Fetch 无法稳定读取时做只读复核，并保留 URL、检索日期和核验状态。
>
> 不得调用 Apify、外部 Actor、爬虫服务或任何 MCP 采集器；不登录、不绕过验证码、不提交表单，失败时标记“待核验”。本 Skill 不声明任何外部插件。

本技能处理普通地图检索，不接入第三方批量采集平台。Search 用来找到地图条目和相关商家页，Fetch 用来回读商家官网，Accio Browser Relay 用来查看动态地图页面上公开可见的字段。结果是“公开实体商家候选”，不是购买来的数据库，也不保证存在采购意向。

## 1. 工具契约

| 顺序 | 工具 | 责任 |
| --- | --- | --- |
| 1 | `ask_user` | 确认产品/行业、客户类型、地区、数量和排除项 |
| 2 | `web_search` | 搜索地图条目、商家页和本地行业结果 |
| 3 | `web_fetch` | 核验官网、联系页、门店页、经销商页和公开目录正文 |
| 4 | `browser` | Accio Browser Relay 的白名单标识；打开动态地图页面并读取公开可见字段 |
| 5 | `write` / `present_files` | 写出 CSV；需要保留结构化中间数据时同时写 JSON |

若环境暴露的是 `browser_*` 原子工具，按实际工具列表调用打开、导航、读取、必要分页和关闭标签页能力，不猜测名称。浏览器路线默认只读；不登录地图账号、不处理验证码、不修改地点、不发布评价、不拨号、不发送消息。

## 2. 输入门禁

一次性确认：

1. 产品、行业或用途，例如 automotive parts、hotel supplies；
2. 客户类型，例如 wholesaler、distributor、retailer、showroom、warehouse、factory；
3. 国家、州/省、城市或商圈；
4. 目标数量；未指定时先交付 20 家高相关实体；
5. 是否必须有官网、电话、完整地址或营业状态；
6. 是否排除单店、纯消费者服务、连锁门店或中国供应商。

地区不能只写“欧洲”“中东”等超大范围。先拆到国家，再按主要城市分批；如果用户坚持全区域，先输出分批计划和首批结果。

## 3. 搜索词设计

地图搜索词要接近真实用户在地图框中的输入，不使用复杂 SEO 操作符作为唯一入口：

```text
{product} {customer_type} {city} {country}
{industry} wholesale {city}
{product} distributor near {city}
{customer_type} {product} {region}
Google Maps {product} {customer_type} {city}
```

同时用普通网页查询补充索引：

```text
site:google.com/maps "{product}" "{city}"
"{product}" "{customer_type}" "{city}" address phone
"{product}" distributor "{country}" locations
```

英语市场用英文；非英语市场至少加入当地语言的行业词和客户类型词。每个城市先用 2–5 条短查询验证方向，再扩展相邻城市。

## 4. Search：建立地点候选池

用 `web_search` 记录：商家名、地图 URL/结果 URL、地址摘要、电话摘要、类别、评分/评论数（若摘要明确显示）、官网候选、搜索词和访问日期。

保留：

- 与产品或行业直接相关的批发商、分销商、零售门店、仓库、展厅、工厂或办公室；
- 有公开地址，且类别、简介或官网能支持业务匹配；
- 集团总部、区域运营商或品牌经销网络中与目标地区相关的实体。

剔除或降级：

- 明显停业、永久关闭或地址冲突；
- 纯消费者服务且与采购关系无关；
- 只有聚合目录、没有可确认实体名称；
- 同名但国家、行业或地址不匹配；
- 用户未要求的单个加盟店或大量重复门店。

搜索摘要中的评分、营业时间和电话可能过期，只能标为“Search 摘要”，必须在动态页或官网二次确认后再升级证据等级。

## 5. Fetch：核验官网与联系路径

对每个高价值地点 Fetch：官网首页、About、Contact、Locations/Stores、Brands/Products、Wholesale/Dealer 页面。提取：

- 官方公司名与根域名；
- 总部或目标门店地址；
- 业务电话、企业邮箱、联系表单；
- 产品/品牌/服务匹配；
- 批发、分销、经销、进口、仓储或 B2B 服务线索；
- 营业区域、门店网络或服务国家；
- 来源 URL 与访问时间。

地图电话和官网冲突时，优先记录官网现行信息，同时保留地图字段和冲突说明。官网无法访问时，不把目录站当作官网。

## 6. Accio Browser Relay：地图动态页复核

以下情况才打开 `browser`：

- Search 给出地图链接，需要读取公开地点卡片；
- Fetch 无法读取地图动态内容；
- 需要确认商家类别、地址、电话、官网按钮、营业状态或地点是否重复；
- 需要在一个城市的公开结果中查看少量下一页或相邻结果。

操作顺序：打开地图 URL → 等待地点卡片稳定 → 读取商家名、类别、地址、电话、官网、营业状态和当前 URL → 必要时打开官网按钮并交给 Fetch 深挖 → 记录访问日期 → 关闭标签。

不得无限滚动或自动遍历整个区域；不得规避频控、登录墙、验证码或地区限制。出现阻断时停止该页面，用普通搜索与官网来源补齐，并明确标记“地图动态页未复核”。

## 7. 主体合并与去重

去重键按以下顺序：明确地点 URL/Place 标识 > 根域名 + 地址 > 电话 + 地址 > 标准化名称 + 城市。连锁品牌默认优先保留总部或区域运营商；只有用户明确要单店名单时才逐店保留。

同一公司多地点时：

- 总部和仓库属于不同开发入口，可分两行但写明关联；
- 完全重复门店合并来源；
- 地区子公司与母公司不能静默合并；
- 电话、地址或官网冲突时保留双方证据，不自行裁决。

## 8. 评分与证据等级

| 维度 | 分值 |
| --- | --- |
| 产品/行业匹配 | 25 |
| 客户类型匹配 | 20 |
| 地区与地址匹配 | 15 |
| 官网主体确认 | 15 |
| 电话/邮箱/表单完整度 | 10 |
| 批发/分销/采购线索 | 10 |
| 营业状态和来源新鲜度 | 5 |

`A`：80 分及以上且有官网或两个独立公开来源；`B`：60–79 分；`C`：40–59 分，仅作人工复核；低于 40 分或明显错配则排除。缺失项不得猜分。

## 9. 交付字段

默认 CSV 字段：

```text
priority,score,business_name,company_name,country,region,city,address,
category,business_status,rating,review_count,phone,website,contact_page,
product_match,customer_type_evidence,b2b_clues,map_url,source_urls,
evidence_level,accessed_at,risk_or_pending,search_query
```

评分与评论数只有页面明确显示时才填写，并记录查看日期；不能用评论数推断公司营收、采购量或信誉。多值字段用 ` | ` 分隔，防止表格公式注入。

交付前使用 `delivery-quality-check` 回读 CSV/JSON，核对列数、编码、重复地点、地址、电话、URL、数量、空值标记和来源。文件回读不通过时不得交付。

## 10. 失败与降级

- Search 不可用：无法建立地点池，停止并说明。
- Fetch 不可用：保留地图公开字段，但官网相关判断全部降级。
- Browser Relay 不可用：仍可做 Search + Fetch；动态字段标记未复核。
- 地图出现登录/验证码：立即停止该页，不要求用户交出账号信息。
- 结果不足：交付真实数量和已覆盖城市，不用无关门店凑数。
- 用户要求自动联系或批量操作地点：超出本 Skill，只产出名单与建议。

最终回报实际候选数、A/B/C 数量、文件路径、覆盖城市、未复核字段和下一步人工抽检建议。
