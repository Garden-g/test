# 启动

确认私有 Skill `b2b-instagram-development-xlsx` 可读取，然后等待用户给出业务目标。
