# TokenMind 23 个 Accio Work 智能体套装

版本：1.0.2

这是一个适用于 Windows 和 macOS 的多 Agent Bundle，包含23个 Agent 模板。每个模板都内置一份对应的完整私有 Skill，并统一使用同一张 Logo。

## 安装

请保持当前账号的 Accio Work 正在运行。不要把 ZIP 或模板目录直接放进 `agents/`；安装器需要生成唯一 Agent ID，并改写私有 Skill 的本机安装路径。

Windows PowerShell：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\installer\install-windows.ps1"
```

macOS 终端：

```bash
chmod +x ./installer/install-macos.sh
./installer/install-macos.sh
```

两套启动器都会优先使用 Accio 自带的 Node 运行时，不会主动结束或重启 Accio。自动识别失败时，可以把账号空间键传给 Windows 的 `-AccountKey` 或 macOS 的 `--account-key`；只读预检分别使用 `-DryRun` 和 `--dry-run`。

## 安装器会做什么

- 从 `~/.accio/state/current-space.json` 识别当前个人或团队空间；必要时使用最近15分钟的 Accio SDK 日志作为后备证据。
- 为每个 Agent 生成唯一 `MID-*`，安装到 `~/.accio/accounts/<当前空间>/agents/<MID-*>/`。
- 保证每个 Agent 恰好一个私有 Skill，路径为 `agent-core/skills/<runtimeSkillId>/`，并校验实际内嵌 Logo 的 SHA-256。
- 使用 `.installing-<agentId>` 两阶段安装；不替换已有 Agent，同来源完整安装只跳过创建。
- 从当前空间 `agentType=accio` 的主智能体读取本地 `USER.md` 和 `MEMORY.md`，通过 TokenMind 标记块合并到套装中的23个 Agent；重复运行会更新同一标记块，不会反复追加。
- 不复制会话、日志、缓存、其他账号目录或凭据。

安装后的 Agent 目录包含当前账号的本地用户画像和记忆，请勿直接转发。只有输出 `INSTALL_OK`，并满足 `installed + skipped = 23`、`personalized = 23`、`residue = 0`，才能视为成功。随后请手动完整退出并重新打开 Accio Work。
