# TokenMind 23 个 Accio Work 智能体套装

版本：1.0.1

这是一个多 Agent Bundle，不是单个 AgentHub 实例包。它包含 23 个 Agent 模板；每个模板都内置一份对应的完整私有 Skill，并统一使用同一张 Logo。

## 安全安装方式

不要直接把模板目录复制进 Accio，因为模板 ID 是占位符，Skill 的安装路径也需要根据接收方账号改写。

Windows 电脑请保持 Accio Work 正在运行，然后在 PowerShell 中执行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\installer\install-windows.ps1
```

脚本会自动读取正在运行的 Accio.exe 路径，并使用 Accio 自带的 Node 运行安装器；不要求接收方预装 Node.js。只有无法读取 Accio 进程路径时，才回退到系统 Node.js。

安装器会：

- 优先读取 `~/.accio/state/current-space.json`；
- Accio 0.27.3 切换账号后该文件暂时不存在时，使用最近 15 分钟的 Accio SDK 运行日志识别当前账号；
- 为每个 Agent 生成唯一 `MID-*`；
- 更新 `profile.jsonc.id` 和私有 Skill 的 `installPath`；
- 使用 `.installing-<agentId>` 两阶段安装；
- 不覆盖已有 Agent；
- 重复执行时跳过已完整安装的同一来源 Agent；
- 成功后输出 `INSTALL_OK`。

## 明确指定账号空间

自动识别失败时，可以传入账号空间键：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\installer\install-windows.ps1 -AccountKey <accountId或accountId_teamId>
```

也可以先做只读预检：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\installer\install-windows.ps1 -DryRun
```

安装完成后请完整退出并重新打开 Accio Work。安装器不会主动结束或重启 Accio。
