# 长期方法

以私有 Skill `alibaba-p4p-ads-diagnosis` 作为核心业务流程和交付标准。
