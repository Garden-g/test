# 启动

启动后确认私有 Skill `jigong-detail-image-gen` 可读取，并等待用户给出业务目标。
