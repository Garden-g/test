---
name: jigong-detail-image-gen
description: "鸡公详情 Skill V2：生成 8 张 750×500、3:2 横版、全英文 B2B 详情卖点图。"
source: 鸡公老师原始资料
---

# 鸡公详情SKILL — 阿里国际站详情页卖点图生成器 v2.0

> 输入：产品白底图 + 卖点描述（场景A）或 白底图 + 同行链接（场景B）
> 输出：8张完整系列详情页英文卖点图，覆盖品质、定制、流程三大维度
> 铁律：图片内容100%英文，零中文，B2B专业视觉风格
> **默认尺寸：750×500 像素（3:2 横版），生图时 aspect_ratio="3:2"**

---

## ⛔ 执行红线（违反即停）

| # | 红线 | 违反后果 |
|---|------|----------|
| R1 | 必须先分析产品图或抓取链接，禁止凭空生图 | 直接拒绝 |
| R2 | 所有生成图片内容严禁出现任何中文字符 | 重新生图 |
| R3 | 场景B必须实际调用 web_fetch 抓取链接内容，禁止猜测竞品信息 | 直接拒绝 |
| R4 | 每张图必须包含 Headline + 至少2条英文说明文案 | 重新生图 |
| R5 | 8张图必须涵盖规定的8个维度，不可合并或跳过 | 重新生图 |
| R6 | image_edit 必须使用 complex_generation task_type | 降级警告 |
| R7 | 所有图片必须使用用户提供的原始产品图作为 reference_image | 重新生图 |
| R8 | 图片尺寸默认 750×500（aspect_ratio="3:2"），除非用户另行指定 | 重新生图 |

---

## 🚦 两种工作场景

### 场景 A：白底图 + 产品卖点文字

```
输入：
  - 产品白底图（URL 或本地路径）
  - 中英文卖点描述（5条以上最佳）

执行：
  1. see_image 分析产品结构、材质、细节特征
  2. 将卖点文字转化为专业英文 B2B 术语
  3. 并行调用 image_edit × 8 生成全套图（aspect_ratio="3:2"）
```

### 场景 B：白底图 + 同行产品链接

```
输入：
  - 产品白底图（URL 或本地路径）
  - 1-2个竞品/参考链接（alibaba.com 或其他平台）

执行：
  1. web_fetch 抓取链接，提取定制能力信息
  2. see_image 分析用户产品图
  3. 将竞品定制能力平移到用户产品
  4. 并行调用 image_edit × 8 生成全套图（aspect_ratio="3:2"）
```

---

## 📐 8张详情图标准输出规范

> 所有图片：aspect_ratio="3:2"（对应 750×500 像素），白底，专业 B2B 风格，全英文。

### 图1 — Brand Positioning Banner（品牌定位横幅）
- Headline：产品核心价值
- Subtitle：材质 + 服务能力
- 底部 3 个 Badge：目标客群
- 布局：产品图居中，文字上下分布；横版 3:2

### 图2 — Key Features & Benefits（核心卖点清单）
- Headline："Key Features & Benefits"
- 布局：产品图在左，右侧 4 条 checkmark 卖点列表
- 每条格式："[功能名称] – [一句话说明]"

### 图3 — Product Detail Four-Quadrant（局部细节放大）
- 产品图居中，四个圆形放大镜细节圈连线指向对应部位
- 4个细节标注：材质纹理 / 工艺细节 / 内衬保护 / 闭合结构

### 图4 — Size Guide（尺寸规格说明）
- Headline：尺寸适配标题
- 展示尺码 + 测量箭头 + 尺寸表
- 底部：Custom Dimensions Available Upon Request

### 图5 — Logo Customization（Logo定制工艺）
- Headline："Professional Logo Customization"
- 产品图居中，四周4个工艺方块连线
- 底部：MOQ 信息 + Free Artwork Support

### 图6 — Color Customization（颜色定制能力）
- Headline："20+ Colors Available – Custom Pantone Matching"
- 多色产品阵列 + 底部色块调色板

### 图7 — Packaging Solutions（包装方案定制）
- Headline："Flexible Packaging Solutions"
- 三种包装方案并排展示
- 底部：QC Report Included | Custom Packaging Available

### 图8 — OEM/ODM Workflow（定制合作流程图）
- Headline："OEM/ODM Customization Process"
- 6步横向流程（左→右，箭头连接）
- 产品图在右下角点缀

---

## 🔧 标准执行流程（SOP）

```
Step 1：接收输入
  ├─ 场景A → 获取：白底图URL + 卖点文字
  └─ 场景B → 获取：白底图URL + 竞品链接

Step 2：信息解析
  ├─ see_image 分析产品图（品类/材质/结构/关键细节）
  └─ 场景B额外：web_fetch 抓取竞品链接，提取定制能力并平移

Step 3：文案转化
  · 转化为专业英文 B2B 术语，无中文 / 无口语化 / 无虚假参数

Step 4：并行生图（8张同步）
  · 8张 image_edit 调用同步并行
  · task_type="complex_generation"
  · 每张挂载用户产品白底图作为 reference_image
  · aspect_ratio="3:2"（750×500，鸡公详情默认标准）

Step 5：交付展示
  · Markdown 图片语法逐张展示 ![标题](URL)
  · 标注每张图核心功能；提示哪张需修改
```

---

## 📋 关键词提取指南（场景B专用）

| 类别 | 提取目标 | 英文标准术语 |
|------|----------|--------------|
| 材质 | 面料/皮料/衬里 | PU Leather / Microfiber / Velvet Lining |
| Logo工艺 | 印花/绣花/烫金 | Embroidery / Silk Screen / Gold Stamping / Rubber Patch |
| 颜色 | 支持颜色数量 | 20+ Colors / Pantone Matching |
| 尺寸 | 适配规格 | S/M/L/XL/XXL / Custom Sizing |
| MOQ | 最低起订量 | MOQ 50pcs |
| 认证 | 质量认证 | CE / BSCI / ISO9001 |
| 包装 | 包装形式 | Polybag / Color Box / Gift Box |
| 交期 | 打样/生产周期 | Sample 7 Days / Production 15-20 Days |

---

## ✅ 交付自检清单（生图完成后逐项核验）

| # | 检查项 | 标准 |
|---|--------|------|
| C1 | 图片总数 | 必须 = 8张 |
| C2 | 中文检查 | 所有图片内容零中文 |
| C3 | 覆盖维度 | 定位/卖点/细节/尺寸/Logo/颜色/包装/流程 各1张 |
| C4 | 产品图引用 | 每张均使用用户提供的白底图 |
| C5 | 图片可访问 | 所有 URL 返回有效图片 |
| C6 | 文案专业度 | 无口语化/无硬翻中文/无虚假参数 |
| C7 | Headline | 每张图均有清晰的英文标题 |
| C8 | 尺寸规格 | aspect_ratio="3:2"（750×500） |
| C9 | 展示格式 | 全部以 Markdown ![](url) 格式内嵌展示 |

---

## 💡 文案质量标准

### ✅ 合格英文文案示例
```
"Intarsia Jacquard Knit – Bold Two-Color Pattern, No Printing Fade"
"Soft Acrylic-Cotton Blend – Breathable & Comfortable All-Day Wear"
"Reinforced Ribbed Trims – Shape-Retaining Collar, Cuffs & Hem"
```

### ❌ 不合格文案（禁止出现）
```
"防水PU皮革" ← 含中文，直接拒绝
"Good quality material" ← 太口语化
"Customizable" ← 孤立词
"TBD" / "待补充" ← 占位词
```

---

## 🚀 一句话定位

> 鸡公详情SKILL = 给产品白底图 + 卖点/竞品链接，自动输出8张阿里国际站英文详情卖点图（默认 750×500 横版）
