# 8张详情图 Prompt 模板库

> 使用时将 [PRODUCT_TYPE] / [MATERIAL] / [FEATURE_X] 替换为实际内容

---

## 图1 — Brand Positioning Banner

```
Create a professional B2B product detail page banner image. White background.
Place the [PRODUCT_TYPE] product image in the center.
Add bold headline text at the top: "[CORE_VALUE_HEADLINE]".
Below the headline add subtitle: "[MATERIAL] | [SERVICE_CAPABILITY]".
At the bottom add three badge icons in a row:
  Badge 1: "[TARGET_BUYER_1]" with relevant icon.
  Badge 2: "[TARGET_BUYER_2]" with relevant icon.
  Badge 3: "OEM/ODM Ready" with a factory icon.
All text in professional English only. Clean, modern, premium feel. No Chinese characters.
```

**变量示例（高尔夫球头套）：**
- PRODUCT_TYPE = Golf Headcovers
- CORE_VALUE_HEADLINE = Premium Customizable Golf Headcovers
- MATERIAL = Top-Grade Microfiber PU Leather
- SERVICE_CAPABILITY = One-Stop OEM/ODM Solution
- TARGET_BUYER_1 = Golf Brands
- TARGET_BUYER_2 = Corporate Gift Suppliers

---

## 图2 — Key Features & Benefits

```
Create a professional product detail infographic on white background.
[PRODUCT_TYPE] product image on the left side.
On the right side, add a vertical list of 4 key feature points with checkmark icons:
  ① "[FEATURE_1_NAME] – [FEATURE_1_DESC]"
  ② "[FEATURE_2_NAME] – [FEATURE_2_DESC]"
  ③ "[FEATURE_3_NAME] – [FEATURE_3_DESC]"
  ④ "[FEATURE_4_NAME] – [FEATURE_4_DESC]"
Bold section title at top: "Key Features & Benefits".
All text in English only, clean sans-serif font. No Chinese.
```

**变量示例（高尔夫球头套）：**
- FEATURE_1 = All-Weather Waterproof Protection – Keeps club heads dry even in heavy rain
- FEATURE_2 = Thickened Velvet Shockproof Lining – Prevents scratches and paint damage
- FEATURE_3 = Premium Microfiber PU Leather – Durable and professional look
- FEATURE_4 = Precise Fit – Driver, Fairway Wood & Hybrid covered

---

## 图3 — Product Detail Four-Quadrant

```
Create a four-quadrant product detail zoom image on white background.
The [PRODUCT_TYPE] product is in the center.
Four circular zoom callouts at the four corners connected by lines to the product:
  Top-left: Close-up of [DETAIL_1_PART], label: "[DETAIL_1_LABEL]"
  Top-right: Close-up of [DETAIL_2_PART], label: "[DETAIL_2_LABEL]"
  Bottom-left: Close-up of [DETAIL_3_PART], label: "[DETAIL_3_LABEL]"
  Bottom-right: Close-up of [DETAIL_4_PART], label: "[DETAIL_4_LABEL]"
All text English only, professional technical annotation style. No Chinese.
```

**变量示例（高尔夫球头套）：**
- DETAIL_1 = PU leather texture → "Wear-Resistant Waterproof PU Leather"
- DETAIL_2 = Embroidery logo → "High-Density 3D Embroidery"
- DETAIL_3 = Velvet lining interior → "Thickened Velvet Shockproof Lining"
- DETAIL_4 = Magnetic closure → "Strong Magnetic / Elastic Closure"

---

## 图4 — Size Guide

```
Create a professional size guide infographic on white background.
Headline at top: "Precision Fit for Every [PRODUCT_CATEGORY] Type".
Show [SIZE_COUNT] product variants arranged from largest to smallest with measurement arrows and labels:
  Largest: "[SIZE_1_NAME] – [SIZE_1_SPEC]"
  Medium: "[SIZE_2_NAME] – [SIZE_2_SPEC]"
  Smallest: "[SIZE_3_NAME] – [SIZE_3_SPEC]"
Below all: "Custom Dimensions Available Upon Request".
Clean technical diagram style, English only. No Chinese.
```

**变量示例（高尔夫球头套）：**
- SIZE_1 = Driver #1 – 460cc Compatible
- SIZE_2 = Fairway Wood #3 / #5
- SIZE_3 = Hybrid / Utility (UT)

---

## 图5 — Logo Customization

```
Create a logo customization capability infographic on white background.
Headline: "Professional Logo Customization".
Place the [PRODUCT_TYPE] product in the center.
Surround it with 4 customization method boxes connected by lines:
  Box 1: "[LOGO_METHOD_1]" with icon
  Box 2: "[LOGO_METHOD_2]" with icon
  Box 3: "[LOGO_METHOD_3]" with icon
  Box 4: "[LOGO_METHOD_4]" with icon
Footer text: "Minimum [MOQ]pcs per design | Free Artwork Support".
All English, clean professional layout. No Chinese.
```

**标准Logo工艺选项（按行业选择4个）：**
- Embroidery（刺绣）
- Silk Screen Printing（丝网印花）
- Embossed / Debossed（压纹/凹纹）
- Rubber Patch（橡胶标）
- Heat Transfer（热转印）
- Gold / Silver Foil Stamping（烫金/烫银）
- Woven Label（织唛）
- Laser Engraving（激光雕刻）

---

## 图6 — Color Customization

```
Create a color customization infographic on white background.
Bold headline at top: "[COLOR_COUNT]+ Colors Available – Custom Pantone Matching".
The product image shown with multiple color variants.
At the bottom show a horizontal color swatch palette bar with [COLOR_COUNT]+ color circles
  covering: red, black, white, navy, blue, green, yellow, pink, orange, purple,
  gray, brown, beige, teal, burgundy, gold, silver, coral, mint, lavender.
Footer: "High Color Fastness | Pantone Color Matching Supported".
All text English only. No Chinese.
```

**常用颜色数量：** 20+ / 30+ / 50+（根据实际生产能力填写）

---

## 图7 — Packaging Solutions

```
Create a packaging solutions infographic on white background.
Headline: "Flexible Packaging Solutions".
Show three packaging options side by side with icons:
  Option 1 (left): [PKG_1_TYPE] icon – label "[PKG_1_NAME] – [PKG_1_DESC]"
  Option 2 (center): [PKG_2_TYPE] icon – label "[PKG_2_NAME] – [PKG_2_DESC]"
  Option 3 (right): [PKG_3_TYPE] icon – label "[PKG_3_NAME] – [PKG_3_DESC]"
Below all three: "QC Report Included | Customized Packaging Available".
Product shown at top center. All English. No Chinese.
```

**标准包装选项：**
- OPP Polybag – Basic Protection（OPP袋）
- Export Carton – Secure Bulk Shipping（出口纸箱）
- Individual Color Box – Retail Ready（彩盒）
- Custom Gift Box – Premium Presentation（礼盒）
- Blister Card – Retail Display（吸塑卡）

---

## 图8 — OEM/ODM Workflow

```
Create a professional OEM/ODM workflow diagram on white background.
Headline: "OEM/ODM Customization Process".
Six steps in a left-to-right horizontal flow with arrows between each step:
  Step 1: "① Inquiry & Brief" – discuss your specific requirements
  Step 2: "② Artwork & Mockup" – free 3D design within 24 hours
  Step 3: "③ Sample in [SAMPLE_DAYS] Days" – rapid prototyping
  Step 4: "④ Order Confirmation" – finalize details and contract
  Step 5: "⑤ Mass Production" – strict QC throughout manufacturing
  Step 6: "⑥ Worldwide Delivery" – safe packaging and fast shipping
Small product image at bottom right corner.
Clean, professional, modern design. All English. No Chinese.
```

**常用打样周期：** 3 Days / 5 Days / 7 Days（根据实际能力填写）

---

## 通用品质标准

### 推荐英文术语库（按材质分类）

**PU / 皮革类**
- Premium PU Leather / Microfiber PU Leather
- Wear-Resistant / Scratch-Resistant / Waterproof
- Soft-Touch Surface / Matte Finish / Glossy Finish

**内衬类**
- Velvet Lining / Fleece Lining / Suede Lining
- Thickened Shockproof Lining
- Anti-Scratch Interior Protection

**工艺类**
- High-Density 3D Embroidery
- Reinforced Double Stitching
- Seamless Construction / Precision Cut & Sew

**闭合类**
- Strong Magnetic Closure
- Elastic Band Closure
- Velcro Closure / Zipper Closure
