# B2B English Copywriting Guide for Alibaba Detail Pages

> 专为阿里国际站买家设计的英文文案撰写规范

---

## 一、B2B 买家心理模型

国际站买家在看详情页时的核心问题（优先级从高到低）：

1. **Is it real?** — 品质是否真实可靠？（材质/工艺/认证）
2. **Can you customize?** — 能否满足我的定制需求？（Logo/颜色/尺寸）
3. **What's the minimum?** — 起订量和价格是否合适？（MOQ/价格）
4. **How long?** — 交货期多久？（打样/生产周期）
5. **Will it arrive safely?** — 包装和物流是否可靠？（包装/运输）

---

## 二、Headline 写作公式

### 公式 1：[属性] + [品类]
```
Premium Customizable Golf Headcovers
Waterproof PU Leather Club Protectors
Heavy-Duty Ergonomic Office Chairs
```

### 公式 2：[数字] + [能力]
```
20+ Colors Available for Custom Orders
3-Day Rapid Sample Service
50pcs Low MOQ, No Minimum Color Limit
```

### 公式 3：[功能] + [结果]
```
Thickened Velvet Lining – Zero Club Damage
All-Weather Waterproof – Performance in Rain
Precision Fit Design – Works with All Major Brands
```

---

## 三、Feature 描述公式

每条 Feature 必须包含：**功能名称 + 破折号 + 一句话利益说明**

```
✅ 正确格式：
"Wear-Resistant Waterproof PU Leather – Maintains premium look after 3+ years of use"
"High-Density 3D Embroidery – Sharp logo definition with 0.1mm precision stitching"

❌ 错误格式：
"Good quality material" （太笼统，无信息量）
"Customizable" （孤立词，无说明）
"PU皮革防水" （含中文，直接拒绝）
```

---

## 四、行业术语对照表

| 中文 | 错误英文 | 正确英文 |
|---|---|---|
| 仿皮 | Fake leather | PU Leather / Synthetic Leather |
| 绣花 | Embroider | Embroidery / Embroidered Logo |
| 印花 | Print flower | Silk Screen Printing / Sublimation Print |
| 烫金 | Hot gold | Gold Foil Stamping / Metallic Foil Transfer |
| 橡胶标 | Rubber mark | Rubber Patch / 3D Rubber Label |
| 内衬 | Inner layer | Lining / Interior Lining |
| 绒布 | Plush cloth | Velvet / Fleece / Microfiber Lining |
| 磁扣 | Magnetic buckle | Magnetic Closure / Magnetic Snap |
| 起订量 | Min order | MOQ (Minimum Order Quantity) |
| 打样 | Make sample | Prototyping / Sampling |
| 彩盒包装 | Color box | Individual Color Box |
| 礼盒 | Gift package | Premium Gift Box |
| 塑料袋 | Plastic bag | OPP Polybag / PE Bag |
| 出口箱 | Export box | Standard Export Carton |
| 潘通色 | Pantone | Pantone Color Matching |
| 色牢度 | Color fastness | Color Fastness / High Color Retention |

---

## 五、尺码/规格表达规范

### 高尔夫类
```
Driver: #1 / 460cc max / Largest head
Fairway Wood: #3, #5, #7
Hybrid / Utility: H, UT, X
Putter: Standard / Mallet / Blade
```

### 服装类
```
XS / S / M / L / XL / XXL / 3XL
US sizing / EU sizing / Asian sizing
Custom sizing available upon request
```

### 包袋类
```
Dimensions: L × W × H (cm or inch)
Volume: XXL (capacity in liters)
Weight capacity: up to XX kg
```

---

## 六、禁用词黑名单

以下词语禁止出现在任何详情图文案中：

```
❌ 中文字符（任何）
❌ TBD / TBC / Coming Soon
❌ 待补充 / 待确认
❌ example.com / yourlogo.com
❌ Good / Nice / Best（过于笼统）
❌ Very / Really / Extremely（副词堆砌）
❌ Cheap / Low price（避免低端定位）
❌ Trust us / We promise（空话）
```

---

## 七、认证标志英文写法

| 认证 | 正确写法 |
|---|---|
| CE认证 | CE Certified |
| BSCI | BSCI Audited Factory |
| ISO9001 | ISO 9001:2015 Certified |
| 环保材质 | Eco-Friendly / RoHS Compliant |
| SGS检测 | SGS Tested & Certified |
| 专利 | Patented Design (Patent No. XXXX) |
