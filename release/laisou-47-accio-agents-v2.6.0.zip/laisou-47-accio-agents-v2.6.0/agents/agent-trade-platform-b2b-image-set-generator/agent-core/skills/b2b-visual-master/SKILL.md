---
name: b2b-visual-master
description: "鸡公老师黄金六张主图：首图、卖点、技术、场景、认证和转化。"
source: 鸡公老师原始资料
---

# 阿里巴巴国际站 B2B 视觉转化大师

本技能旨在帮助阿里巴巴国际站卖家快速生成高转化的“黄金6张主图”。该体系将 B2B 采购决策路径拆解为 6 个视觉触点，通过 AI 自动化成图，提升询盘率。

## 核心策略：黄金6张图漏斗 (6-Image Funnel)

### 1. 图1：全能首图 (Hero Image)
- **目标**：建立大厂专业度，吸引点击。
- **元素**：产品全家福 + 核心规格（Watt/Capacity/Material）+ 工厂年限背书（15+ Years Factory）。
- **风格**：高对比度，干净背景，工业高级感。

### 2. 图2：核心卖点 (Key Selling Points)
- **目标**：展示功能多样性。
- **元素**：控制面板特写 + 应用 Icon（充电速度、接口数量、工艺精度）。
- **文案**：Powers 7 Devices Simultaneously / Ultra-Fast Charging 等。

### 3. 图3：技术/安全 (Technical & Safety)
- **目标**：消除质量顾虑。
- **元素**：半透明拆解图 / 内部核心部件（BMS/主板）+ 保护层标注（10-Layer Protection）。
- **背景**：微虚化的工厂流水线或实验室。

### 4. 图4：应用场景 (Application Scenarios)
- **目标**：产生情感连接与代入感。
- **元素**：真实使用环境（Camping/Office/Home/Industrial）。
- **拍摄风格**：Lifestyle 风格，强调产品在生活/工作中的实际作用。

### 5. 图5：认证背书 (Global Certifications)
- **目标**：降低合规风险。
- **元素**：证书矩阵（CE/UL/FCC/UN38.3/RoHS/BSCI）+ 100% QC 质检声明。
- **布局**：整洁、权威，背景为质检车间。

### 6. 图6：促单转化 (CTA & Service)
- **目标**：引导买家发送询盘。
- **元素**：仓库库存/礼盒展示 + OEM/ODM 支持文案 + "INQUIRY NOW" 橙色按钮。
- **文案**：Ready to Ship / Low MOQ / Free Sample Design。

## 使用说明
1. **输入图片**：向智能体发送产品白底图或实拍图。
2. **品类指定**：若未自动识别，请补充告知产品品类（如：户外储能、五金、服装）。
3. **自动化出图**：智能体将自动提取品牌色，按照上述 6 步逻辑生成全套设计初稿。

## 视觉标准
- **字体**：强制使用 Montserrat Bold 或 Roboto。
- **配色**：自动提取产品品牌色（如活力橙、工业蓝）作为 UI 装饰色。
- **Icon**：使用线性的、符合欧美 B2B 审美的扁平化图标。
