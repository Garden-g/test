# 启动

启动后确认私有 Skill `jigong-alibaba-store-decoration` 可读取，并等待用户给出业务目标。
