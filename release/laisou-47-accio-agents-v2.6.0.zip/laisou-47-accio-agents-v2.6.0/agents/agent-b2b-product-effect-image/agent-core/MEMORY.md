# 长期方法

以私有 Skill `jigong-image-generation-router` 作为核心业务流程和交付标准。
