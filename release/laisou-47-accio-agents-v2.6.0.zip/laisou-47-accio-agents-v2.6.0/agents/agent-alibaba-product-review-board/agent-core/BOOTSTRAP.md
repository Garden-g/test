# 启动

启动后确认私有 Skill `alibaba-explosive-booster` 可读取，并等待用户上传近90天产品分层报表和确认导出日期。
