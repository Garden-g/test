#!/usr/bin/env python3
"""按鸡公老师 V5 规则生成优爆品分层 Excel。

脚本保留原分享包的分层阈值和工作簿结构，但将原脚本中的 Windows
绝对路径改为命令行参数，并恢复 HTTPS 证书验证，便于安全分发和复用。
"""

from __future__ import annotations

import argparse
import hashlib
import logging
import tempfile
import urllib.error
import urllib.request
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence, TypeAlias

from openpyxl import Workbook, load_workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.drawing.spreadsheet_drawing import AnchorMarker, TwoCellAnchor
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.utils.units import pixels_to_EMU
from PIL import Image as PILImage


LOGGER = logging.getLogger("alibaba_explosive_booster")

CellValue: TypeAlias = Any
ProductRow: TypeAlias = Mapping[str, CellValue]
ClassifiedRow: TypeAlias = tuple[ProductRow, str, str]

REQUIRED_COLUMNS = {
    "产品ID",
    "产品类型",
    "近90天[TM+询盘]人数",
    "近90天支付买家数",
    "近30天访问人数",
}

CATEGORIES = [
    "爆品-重点关注",
    "潜力爆品-关注",
    "48H成为优品-爆品",
    "优品",
    "普通品+潜力优品",
]

THEME = {
    "爆品-重点关注": ("C00000", "F8CBAD"),
    "潜力爆品-关注": ("7030A0", "D9C2E9"),
    "48H成为优品-爆品": ("C45911", "F8CBAD"),
    "优品": ("548235", "C6E0B4"),
    "普通品+潜力优品": ("2E75B6", "BDD7EE"),
    "假爆品": ("808080", "D9D9D9"),
}

STRATEGIES = {
    "爆品-重点关注": "重点推广，加入橱窗，积累有色眼镜，快速打造超级爆品",
    "潜力爆品-关注": "单独计划推广，加入橱窗，积累资源",
    "48H成为优品-爆品": "类型互改或补广告访客，48H 提升",
    "优品": "单独创建优品计划，快速选出潜力爆品",
    "普通品+潜力优品": "优化标题和副标题，加入全站推测款",
}


def parse_args() -> argparse.Namespace:
    """解析命令行参数。

    Returns:
        argparse.Namespace: 包含输入文件、输出文件、数据日期和图片下载开关。

    Raises:
        SystemExit: 必需参数缺失或参数格式无效时由 argparse 抛出。
    """
    parser = argparse.ArgumentParser(description="生成优爆品提升分层 Excel")
    parser.add_argument("--input", required=True, type=Path, help="近90天产品分层报表 .xlsx")
    parser.add_argument("--output", required=True, type=Path, help="输出 .xlsx 路径")
    parser.add_argument("--date", required=True, help="报表导出日期，格式 YYYY.MM.DD")
    parser.add_argument(
        "--skip-images",
        action="store_true",
        help="跳过网络图片下载；分层与表格仍正常生成",
    )
    return parser.parse_args()


def configure_logging() -> None:
    """配置运行日志。

    Returns:
        None: 日志直接输出到当前进程标准错误流。

    Raises:
        Exception: logging.basicConfig 通常不抛异常；若运行环境拒绝初始化则向上传递。
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )


def clean(value: CellValue) -> str:
    """清理单元格文本，用于稳定匹配列名和类型字段。

    Args:
        value (Any): 从 Excel 读取的任意单元格值。

    Returns:
        str: 去除换行、制表符和首尾空白后的文本。

    Raises:
        Exception: 自定义对象在转换为字符串时的异常会向上传递。
    """
    if value is None:
        return ""
    return str(value).replace("\n", "").replace("\t", "").strip()


def to_number(value: CellValue) -> float:
    """将 Excel 中的数值、百分比文本或空值转为浮点数。

    Args:
        value (Any): 需要转换的单元格值。

    Returns:
        float: 解析后的数字；空值、`-` 或无法解析的值返回 0。

    Raises:
        Exception: 函数已吸收常见转换异常，通常不向外抛出。
    """
    if value in (None, "", "-"):
        return 0.0
    try:
        return float(str(value).replace("%", "").replace(",", ""))
    except (TypeError, ValueError):
        return 0.0


def load_rows(input_path: Path) -> tuple[list[str], list[dict[str, CellValue]]]:
    """读取源工作簿并将数据行转为列名映射。

    Args:
        input_path (Path): 用户上传的近90天产品分层报表。

    Returns:
        tuple[list[str], list[dict[str, Any]]]: 源列名顺序和已过滤空产品 ID 的数据行。

    Raises:
        FileNotFoundError: 输入文件不存在。
        ValueError: 找不到表头或缺少分层所需的关键列。
        OSError: 文件无法读取或不是有效 XLSX 时向上传递。
    """
    if not input_path.is_file():
        raise FileNotFoundError(f"输入文件不存在: {input_path}")

    workbook = load_workbook(input_path, data_only=True, read_only=True)
    worksheet = workbook.active
    raw_rows = list(worksheet.iter_rows(values_only=True))

    header_index = next(
        (index for index, row in enumerate(raw_rows) if "产品ID" in [clean(cell) for cell in row]),
        None,
    )
    if header_index is None:
        raise ValueError("未找到包含‘产品ID’的表头行")

    raw_headers = [clean(cell) for cell in raw_rows[header_index]]
    headers = [header for header in raw_headers if header and header != "优化建议"]
    missing = sorted(REQUIRED_COLUMNS.difference(headers))
    if missing:
        raise ValueError(f"缺少必需列: {', '.join(missing)}")

    header_positions = {header: raw_headers.index(header) for header in headers}
    products: list[dict[str, CellValue]] = []
    for raw_row in raw_rows[header_index + 1 :]:
        product = {
            header: raw_row[position] if position < len(raw_row) else None
            for header, position in header_positions.items()
        }
        if product.get("产品ID") not in (None, ""):
            products.append(product)

    if not products:
        raise ValueError("报表中没有可分析的产品数据")
    return headers, products


def product_type(row: ProductRow) -> str:
    """将报表中的产品类型归一为交易品或商机品。

    Args:
        row (Mapping[str, Any]): 一条产品数据。

    Returns:
        str: `交易品` 或 `商机品`。

    Raises:
        Exception: 字段转换为字符串的异常会向上传递。
    """
    value = clean(row.get("产品类型")).lower()
    transaction_markers = ("ready to ship", "直接下单", "交易品")
    return "交易品" if any(marker in value for marker in transaction_markers) else "商机品"


def classify(row: ProductRow) -> tuple[str, str]:
    """严格按鸡公老师 V5 优先级对单个商品分层。

    Args:
        row (Mapping[str, Any]): 含产品类型、询盘、支付买家数和访客数的产品数据。

    Returns:
        tuple[str, str]: 主分层名称和对应执行建议；未命中时返回 `其他`。

    Raises:
        Exception: 读取自定义映射时的异常会向上传递。
    """
    kind = product_type(row)
    inquiries = to_number(row.get("近90天[TM+询盘]人数"))
    buyers = to_number(row.get("近90天支付买家数"))
    visitors = to_number(row.get("近30天访问人数"))

    if (kind == "商机品" and inquiries >= 20 and buyers >= 3) or (
        kind == "交易品" and inquiries >= 10 and buyers >= 5
    ):
        return "爆品-重点关注", STRATEGIES["爆品-重点关注"]
    if (kind == "商机品" and inquiries >= 10) or (
        kind == "交易品" and inquiries >= 10 and buyers < 5
    ):
        return "潜力爆品-关注", STRATEGIES["潜力爆品-关注"]
    if kind == "商机品" and inquiries >= 2 and visitors == 0:
        return "48H成为优品-爆品", "商机品加入广告补 1 个访客，48H 成为优品"
    if kind == "交易品" and inquiries >= 2 and buyers == 0 and visitors > 1:
        return "48H成为优品-爆品", "交易品改为商机品，48H 成为优品"
    if kind == "交易品" and buyers >= 1 and visitors == 0:
        return "48H成为优品-爆品", "交易品加入广告补 1 个访客，48H 成为优品"
    if (kind == "商机品" and inquiries >= 2 and visitors >= 1) or (
        kind == "交易品" and inquiries >= 1 and buyers >= 1
    ):
        return "优品", STRATEGIES["优品"]
    if inquiries <= 1 and visitors >= 1:
        return "普通品+潜力优品", STRATEGIES["普通品+潜力优品"]
    return "其他", ""


def is_fake_explosive(row: ProductRow) -> bool:
    """判断交易品是否命中鸡公老师的假爆品独立规则。

    Args:
        row (Mapping[str, Any]): 一条产品数据。

    Returns:
        bool: 交易品买家数不少于 5 且询盘小于 10 时为 True。

    Raises:
        Exception: 读取自定义映射时的异常会向上传递。
    """
    return (
        product_type(row) == "交易品"
        and to_number(row.get("近90天支付买家数")) >= 5
        and to_number(row.get("近90天[TM+询盘]人数")) < 10
    )


def normalize_image_url(url: str) -> str:
    """尝试去掉常见的 100x100 缩略图后缀以获取更清晰的原图。

    Args:
        url (str): 报表中的产品图片 URL。

    Returns:
        str: 可能已去除缩略图后缀的 URL。

    Raises:
        Exception: 普通字符串操作通常不抛异常。
    """
    stripped = url.strip()
    for suffix in ("_100x100.jpg", "_100x100.png", "_100x100"):
        if stripped.endswith(suffix):
            return stripped[: -len(suffix)]
    return stripped


def download_image(url: str, image_dir: Path) -> Path | None:
    """使用系统默认 HTTPS 证书验证下载一张产品图片。

    Args:
        url (str): 必须以 http:// 或 https:// 开头的图片链接。
        image_dir (Path): 保存临时图片的目录。

    Returns:
        Path | None: 下载成功的本地文件；链接无效或下载失败时返回 None。

    Raises:
        OSError: 临时目录无法写入时可能向上传递。
    """
    if not url.startswith(("http://", "https://")):
        return None

    normalized = normalize_image_url(url)
    target_path = image_dir / f"{hashlib.sha256(normalized.encode('utf-8')).hexdigest()}.img"
    for candidate in dict.fromkeys((normalized, url)):
        try:
            request = urllib.request.Request(candidate, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(request, timeout=20) as response:
                # 限制单图大小，避免异常资源耗尽内存。
                data = response.read(15 * 1024 * 1024 + 1)
            if 200 < len(data) <= 15 * 1024 * 1024:
                target_path.write_bytes(data)
                return target_path
        except (OSError, urllib.error.URLError, ValueError) as exc:
            LOGGER.warning("图片下载失败 url=%s error=%s", candidate, exc)
    return None


def make_thumbnail(image_path: Path, size: int = 72) -> Path | None:
    """将下载图片转换为可嵌入 Excel 的 RGB PNG 缩略图。

    Args:
        image_path (Path): 已下载的图片文件。
        size (int): 缩略图的最大宽高像素，默认 72。

    Returns:
        Path | None: 生成的 PNG 文件；源图无法解析时返回 None。

    Raises:
        OSError: 某些底层文件系统错误可能向上传递。
    """
    output_path = image_path.with_suffix(f".{size}.png")
    try:
        with PILImage.open(image_path) as image:
            converted = image.convert("RGB")
            converted.thumbnail((size, size))
            converted.save(output_path, "PNG")
        with PILImage.open(output_path) as verification_image:
            verification_image.verify()
        return output_path
    except (OSError, ValueError) as exc:
        LOGGER.warning("图片转换失败 path=%s error=%s", image_path, exc)
        return None


def prepare_images(
    rows: Iterable[ProductRow],
    image_dir: Path,
    skip_images: bool,
) -> dict[str, Path | None]:
    """并发下载报表中的唯一图片链接。

    Args:
        rows (Iterable[ProductRow]): 需要生成报告的产品数据。
        image_dir (Path): 临时图片保存目录。
        skip_images (bool): 是否跳过全部网络下载。

    Returns:
        dict[str, Path | None]: 原始 URL 到本地图片路径的映射。

    Raises:
        OSError: 临时目录无法写入时可能向上传递。
    """
    urls = sorted({clean(row.get("图片链接")) for row in rows if clean(row.get("图片链接"))})
    if skip_images or not urls:
        return {url: None for url in urls}

    LOGGER.info("开始下载产品图片 count=%d", len(urls))
    with ThreadPoolExecutor(max_workers=min(16, len(urls))) as executor:
        downloaded = list(executor.map(lambda url: download_image(url, image_dir), urls))
    return dict(zip(urls, downloaded, strict=True))


def classify_rows(products: Sequence[ProductRow]) -> tuple[list[ClassifiedRow], list[ClassifiedRow]]:
    """生成主分层结果和假爆品独立扫描结果。

    Args:
        products (Sequence[ProductRow]): 已读取的全部有效产品。

    Returns:
        tuple[list[ClassifiedRow], list[ClassifiedRow]]: 主分层列表和假爆品列表。

    Raises:
        Exception: 分层过程中读取自定义数据结构的异常会向上传递。
    """
    classified: list[ClassifiedRow] = []
    fake_rows: list[ClassifiedRow] = []
    fake_advice = (
        "交易品成交买家数>=5但询盘<10：靠老客复购支撑，公域询盘不足。"
        "建议优化标题和主图拉新询盘，避免单一客户依赖。"
    )
    for row in products:
        category, advice = classify(row)
        if category != "其他":
            classified.append((row, category, advice))
        if is_fake_explosive(row):
            fake_rows.append((row, "假爆品", fake_advice))
    return classified, fake_rows


def create_summary_sheet(
    workbook: Workbook,
    classified: Sequence[ClassifiedRow],
    fake_rows: Sequence[ClassifiedRow],
    total_products: int,
    date_text: str,
) -> None:
    """生成老师样板结构的首页汇总 Sheet。

    Args:
        workbook (Workbook): 待写入的输出工作簿。
        classified (Sequence[ClassifiedRow]): 主分层结果。
        fake_rows (Sequence[ClassifiedRow]): 假爆品独立结果。
        total_products (int): 源报表中有效产品数。
        date_text (str): 用户确认的报表导出日期。

    Returns:
        None: 函数直接修改 workbook。

    Raises:
        ValueError: 工作簿无活动工作表时可能抛出。
    """
    sheet = workbook.active
    sheet.title = "首页汇总"
    sheet.sheet_view.showGridLines = False
    sheet["B2"] = "优爆品提升分层报告"
    sheet["B2"].font = Font(name="微软雅黑", bold=True, size=16, color="2E75B6")
    sheet["B3"] = f"数据周期：近90天（{date_text} 导出）"
    sheet["B3"].font = Font(name="微软雅黑", size=10, color="808080")

    white_font = Font(name="微软雅黑", bold=True, size=10, color="FFFFFF")
    normal_font = Font(name="微软雅黑", size=10)
    centered = Alignment(horizontal="center", vertical="center")
    left_vertical = Alignment(horizontal="left", vertical="center")
    thin_border = Border(*[Side(style="thin", color="BFBFBF")] * 4)

    for column, title in enumerate(("分类名称", "产品数量", "执行策略"), start=2):
        cell = sheet.cell(5, column, title)
        cell.fill = PatternFill("solid", fgColor="2E75B6")
        cell.font = white_font
        cell.alignment = centered
        cell.border = thin_border

    counts = Counter(category for _, category, _ in classified)
    current_row = 6
    for category in CATEGORIES:
        sheet.cell(current_row, 2, category)
        sheet.cell(current_row, 3, counts.get(category, 0))
        sheet.cell(current_row, 4, STRATEGIES[category])
        sheet.cell(current_row, 2).fill = PatternFill("solid", fgColor=THEME[category][1])
        for column in range(2, 5):
            cell = sheet.cell(current_row, column)
            cell.font = normal_font
            cell.alignment = centered if column == 3 else left_vertical
            cell.border = thin_border
        current_row += 1

    sheet.cell(current_row, 2, "假爆品（交易品·成交>=5 且 询盘<10）")
    sheet.cell(current_row, 3, len(fake_rows))
    sheet.cell(current_row, 4, "靠老客复购支撑，需优化标题和主图拉新询盘")
    sheet.cell(current_row, 2).fill = PatternFill("solid", fgColor=THEME["假爆品"][1])
    for column in range(2, 5):
        cell = sheet.cell(current_row, column)
        cell.font = normal_font
        cell.alignment = centered if column == 3 else left_vertical
        cell.border = thin_border

    current_row += 1
    sheet.cell(current_row, 2, "在线产品总计")
    sheet.cell(current_row, 3, total_products)
    sheet.cell(current_row, 2).font = Font(name="微软雅黑", bold=True, size=10)
    sheet.cell(current_row, 3).font = Font(name="微软雅黑", bold=True, size=10)
    sheet.column_dimensions["A"].width = 3
    sheet.column_dimensions["B"].width = 34
    sheet.column_dimensions["C"].width = 12
    sheet.column_dimensions["D"].width = 48


def display_headers(source_headers: Sequence[str], category: str) -> list[str]:
    """按高端分类或基础分类规则得到实际输出列。

    Args:
        source_headers (Sequence[str]): 源报表的有效列名顺序。
        category (str): 当前输出的分层名称。

    Returns:
        list[str]: 删除不适用列、重命名图片列并追加优化建议后的列名。

    Raises:
        Exception: 常规列表操作通常不抛异常。
    """
    high_end = category in {"爆品-重点关注", "潜力爆品-关注", "优品", "假爆品"}
    if high_end:
        removed = {"低质品", "潜力优品", "普通品", "半托管品", "产品图片"}
    else:
        removed = {"低质品", "半托管品", "商机优爆品", "交易优爆品", "产品图片"}
    headers = [("产品图片" if header == "图片链接" else header) for header in source_headers if header not in removed]
    return headers + ["优化建议"]


def add_product_sheet(
    workbook: Workbook,
    category: str,
    rows: Sequence[ClassifiedRow],
    source_headers: Sequence[str],
    image_paths: Mapping[str, Path | None],
    date_text: str,
) -> None:
    """生成一个分层明细 Sheet，并按需嵌入产品缩略图。

    Args:
        workbook (Workbook): 待写入的输出工作簿。
        category (str): 当前分层名称。
        rows (Sequence[ClassifiedRow]): 属于该分层的产品数据。
        source_headers (Sequence[str]): 源报表列名顺序。
        image_paths (Mapping[str, Path | None]): 图片 URL 与本地临时文件的映射。
        date_text (str): 报表导出日期。

    Returns:
        None: 函数直接修改 workbook。

    Raises:
        ValueError: 列定位失败或合并范围无效时可能抛出。
        OSError: 图片无法读取时可能向上传递。
    """
    sheet = workbook.create_sheet(category)
    sheet.sheet_view.showGridLines = False
    dark_color, _ = THEME[category]
    headers = display_headers(source_headers, category)
    column_count = len(headers)

    base_names = {"序号", "产品ID", "产品名称", "产品链接", "产品类目", "产品图片", "产品类型", "产品型号", "产品分组"}
    performance_names = {"近30天搜索曝光", "近30天访问人数", "近90天[TM+询盘]人数", "近90天支付买家数", "近90天转化率"}
    base_count = sum(1 for header in headers if header in base_names)
    performance_count = sum(1 for header in headers if header in performance_names)
    layer_start = base_count + 1
    layer_end = column_count - performance_count - 1

    title_category = category.replace("-爆品", "/爆品")
    sheet.merge_cells(start_row=1, start_column=1, end_row=1, end_column=column_count)
    title_cell = sheet.cell(1, 1, f"【{title_category}】分层清单（共 {len(rows)} 款 · 数据周期近90天 {date_text}）")
    title_cell.fill = PatternFill("solid", fgColor=dark_color)
    title_cell.font = Font(name="微软雅黑", bold=True, size=14, color="FFFFFF")
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    title_cell.border = Border(*[Side(style="medium", color="808080")] * 4)
    sheet.row_dimensions[1].height = 34

    # 第 2 行按老师样板分为基础信息、产品分层、数据表现和优化建议。
    if base_count:
        sheet.merge_cells(start_row=2, start_column=1, end_row=2, end_column=base_count)
        sheet.cell(2, 1, "基础信息")
    if layer_end >= layer_start:
        sheet.merge_cells(start_row=2, start_column=layer_start, end_row=2, end_column=layer_end)
        sheet.cell(2, layer_start, "产品分层")
    if performance_count:
        performance_start = column_count - performance_count
        sheet.merge_cells(start_row=2, start_column=performance_start, end_row=2, end_column=column_count - 1)
        sheet.cell(2, performance_start, "数据表现")
    sheet.cell(2, column_count, "优化建议")

    white_font = Font(name="微软雅黑", bold=True, size=10, color="FFFFFF")
    normal_font = Font(name="微软雅黑", size=10)
    centered = Alignment(horizontal="center", vertical="center")
    thin_border = Border(*[Side(style="thin", color="BFBFBF")] * 4)
    for column in range(1, column_count + 1):
        cell = sheet.cell(2, column)
        cell.fill = PatternFill("solid", fgColor=dark_color)
        cell.font = white_font
        cell.alignment = centered
        cell.border = Border(*[Side(style="medium", color="808080")] * 4)

    for column, header in enumerate(headers, start=1):
        cell = sheet.cell(3, column, header)
        cell.fill = PatternFill("solid", fgColor=dark_color)
        cell.font = white_font
        cell.alignment = centered
        cell.border = thin_border
    sheet.row_dimensions[2].height = 28
    sheet.row_dimensions[3].height = 26
    sheet.freeze_panes = "A4"

    if not rows:
        sheet.merge_cells(start_row=4, start_column=1, end_row=4, end_column=column_count)
        empty_cell = sheet.cell(4, 1, "无满足条件的产品")
        empty_cell.font = Font(name="微软雅黑", color="FF0000", bold=True, size=12)
        empty_cell.alignment = centered
    else:
        image_column = headers.index("产品图片") + 1 if "产品图片" in headers else None
        for row_number, (product, _, advice) in enumerate(rows, start=4):
            sheet.row_dimensions[row_number].height = 58
            fill_color = "F2F2F2" if row_number % 2 == 0 else "FFFFFF"
            for column, header in enumerate(headers, start=1):
                source_header = "图片链接" if header == "产品图片" else header
                value = "" if header == "产品图片" else (advice if header == "优化建议" else product.get(source_header))
                cell = sheet.cell(row_number, column, value)
                cell.border = thin_border
                cell.fill = PatternFill("solid", fgColor=fill_color)
                cell.font = normal_font
                cell.alignment = Alignment(
                    horizontal="left" if header in {"产品名称", "优化建议"} else "center",
                    vertical="center",
                    wrap_text=header in {"产品名称", "优化建议"},
                )

            if image_column:
                image_url = clean(product.get("图片链接"))
                downloaded_path = image_paths.get(image_url)
                if downloaded_path:
                    thumbnail = make_thumbnail(downloaded_path)
                    if thumbnail:
                        excel_image = XLImage(thumbnail)
                        padding = pixels_to_EMU(3)
                        excel_image.anchor = TwoCellAnchor(
                            editAs="twoCell",
                            _from=AnchorMarker(col=image_column - 1, colOff=padding, row=row_number - 1, rowOff=padding),
                            to=AnchorMarker(col=image_column, colOff=-padding, row=row_number, rowOff=-padding),
                        )
                        sheet.add_image(excel_image)

    for column, header in enumerate(headers, start=1):
        column_letter = get_column_letter(column)
        if header in {"产品名称", "优化建议"}:
            sheet.column_dimensions[column_letter].width = 55
        elif header == "产品图片":
            sheet.column_dimensions[column_letter].width = 11
        elif header == "产品链接":
            sheet.column_dimensions[column_letter].width = 24
        else:
            sheet.column_dimensions[column_letter].width = min(max(len(header) * 2, 10), 30)


def build_workbook(
    source_headers: Sequence[str],
    products: Sequence[ProductRow],
    output_path: Path,
    date_text: str,
    skip_images: bool,
) -> None:
    """组装并保存完整的优爆品分层工作簿。

    Args:
        source_headers (Sequence[str]): 源报表列名顺序。
        products (Sequence[ProductRow]): 源报表中的有效产品。
        output_path (Path): 最终 Excel 输出路径。
        date_text (str): 报表导出日期。
        skip_images (bool): 是否跳过网络图片下载。

    Returns:
        None: 工作簿保存到 output_path。

    Raises:
        OSError: 输出目录无法创建或文件无法保存。
        ValueError: 工作簿结构异常时可能抛出。
    """
    classified, fake_rows = classify_rows(products)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="alibaba-explosive-booster-") as temp_directory:
        image_paths = prepare_images(products, Path(temp_directory), skip_images)
        workbook = Workbook()
        create_summary_sheet(workbook, classified, fake_rows, len(products), date_text)
        for category in CATEGORIES:
            category_rows = [item for item in classified if item[1] == category]
            add_product_sheet(workbook, category, category_rows, source_headers, image_paths, date_text)
        add_product_sheet(workbook, "假爆品", fake_rows, source_headers, image_paths, date_text)
        workbook.save(output_path)

    counts = Counter(category for _, category, _ in classified)
    LOGGER.info(
        "生成完成 output=%s total=%d fake=%d counts=%s",
        output_path,
        len(products),
        len(fake_rows),
        dict(counts),
    )


def main() -> int:
    """执行命令行入口并返回进程状态码。

    Returns:
        int: 成功生成工作簿时返回 0。

    Raises:
        FileNotFoundError: 输入文件不存在。
        ValueError: 输入表结构或日期参数无效。
        OSError: 文件读写或工作簿保存失败。
    """
    configure_logging()
    args = parse_args()
    if len(args.date) != 10 or args.date[4] != "." or args.date[7] != ".":
        raise ValueError("--date 必须使用 YYYY.MM.DD 格式")
    headers, products = load_rows(args.input)
    build_workbook(headers, products, args.output, args.date, args.skip_images)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
