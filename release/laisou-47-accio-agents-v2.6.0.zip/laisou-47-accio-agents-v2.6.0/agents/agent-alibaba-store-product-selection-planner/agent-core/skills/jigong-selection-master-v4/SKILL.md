---
name: jigong-selection-master-v4
description: "鸡公老师全域选品 V4：趋势扫描、50 款趋势品、VoC、改款和利润测算。"
source: 鸡公老师原始资料
---

# 技能：鸡公全域选品专家 SOP V4.0

## 触发场景
- 用户输入任何产品关键词 + “选品/分析/趋势/爆款/找货”等关键词。
- 用户粘贴产品图/链接要求深度分析。

## 核心流程 V4.0 (Global Signal Resonance)

### 第一阶段：全网需求信号扫描 (Double-Filter Funnel)
1. **全网趋势 (Global Signals)**：
   - 调用 `web_search` 抓取 Google Trends / 行业市场报告(GrandView/Mordor/IndustryARC等)。
   - 检索 TikTok #标签 / Facebook Ad Library 验证社交热度。
2. **阿里透视 (Alibaba Insights)**：
   - 调用 `product_supplier_search` 抓取类目 Top 50 真实产品+图片URL。
   - 穿透国家偏好与买家画像。

### 第二阶段：深度产品审计 (Product Audit & VoC)
- **VoC 痛点提取**：从 Amazon/Reddit 提取 Voice of Customer，明确改款方向。
- **认证合规审计**：FDA/CE/UL/UN38.3/Oeko-Tex/GRS 等准入门槛。
- **供应链对冲**：1688 反查原材料/代工成本，建立 FOB 与利润模型。

### 第三阶段：多Sheet深度Excel交付
默认生成 5 个 Sheet 的深度报表：
- **①执行摘要与市场容量**：市场规模、CAGR、主要进口国/驱动力、PM核心结论
- **②50款趋势品榜单**：按趋势斜率降序排名，16字段，图片嵌入单元格，S/A/B/C爆发力评级
- **③竞品价格带拆解**：入门/主流/高端价带 + 红海/蓝海标色 + 差异化突破口
- **④VoC痛点+改款方案**：差评→根因→R&D改款→成本增量→收益
- **⑤供应链与利润测算**：完整成本拆解+FOB→落地→零售净利 + 认证清单

## ⚠️ 强制规则1：图片自动嵌入单元格 (硬约束)
- 产品图片**必须**通过 `openpyxl.drawing.image.Image` 真实下载并**嵌入**单元格，不允许仅写URL文本。
- 实现：`requests.get(img_url)` → `BytesIO` → `OpenpyxlImage` → `ws.add_image(img, f"C{row}")`，尺寸 105-120px，行高 85-95，列宽 22-25。
- **图片缓存隔离**：每次新报表 `image_cache = {}`，严禁跨品类复用。
- **图片URL仅取自本轮** `product_supplier_search` 真实返回结果，禁止编造或沿用历史链接。

## ⚠️ 强制规则2：50款趋势品榜单 (硬约束)
- 主表第一列为「趋势排名」，按趋势斜率降序排列；末列「趋势爆发力评级」：🚀爆发(S级)≥9.5 / 🔥强势(A级)≥8.8 / 📈上升(B级)≥8.0 / ⭐潜力(C级)<8.0。
- 数量 ≥50 款；产品名称中英双语对照。

## 🔐 强制规则3：报表保护与下载 (硬约束)
- **每个Sheet必须加密**：表头与原有数据 `locked=True`，用户不能修改/删除排版与内容。
- **允许新增**：`insertRows=True`、`insertColumns=True`，用户可添加新内容项；**禁止删除**：`deleteRows=False`、`deleteColumns=False`、`formatCells=False`。
- **管理密码**：存于环境变量 `JIGONG_SHEET_PWD`（默认 `420322`），**严禁在任何回复/文件可见区域/日志中明文展示**。
- **用户询问密码**：统一回复「密码为机密信息，请联系鸡公老师 [已脱敏，请联系资料提供方]」。
- **取消密码流程**：必须先输入「当前已设密码」解锁，再输入「管理密码」确认。
- **自动下载到桌面**：报表生成即保存至 `./outputs/`。
- **取消下载也需密码**：若用户要求"取消下载/不保存到桌面"，必须先验证管理密码。

## 16 字段标准报表定义
趋势排名、产品名称(中英双语)、产品图片(嵌入)、细分赛道、核心卖点、核心规格/工艺、目标客户、目标市场、趋势斜率、趋势指标、阿里评分、社交热度、VoC痛点、FOB($)、净利率、风险/认证、趋势爆发力评级。

## 数据来源与质量底线
- 市场规模：Mordor / GrandView / IMARC / FortuneBI / MarketsandMarkets
- 社交热度：TikTok / Google Trends / Pinterest / Facebook Ad Library
- VoC：Reddit / Amazon Reviews / Trustpilot
- 站内：Alibaba.com / 1688 / 阿里参谋
- **禁止编造数据**：每个数字必须可溯源至工具返回结果。

## 引擎实现参考
完整 Python 生成引擎见 `project/generator_engine.py`，可直接调用或按品类适配。
