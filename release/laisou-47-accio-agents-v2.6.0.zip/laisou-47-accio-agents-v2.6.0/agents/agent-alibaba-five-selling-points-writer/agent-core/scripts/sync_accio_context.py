#!/usr/bin/env python3
"""Synchronize shared USER and MEMORY blocks with the Accio Assistant.

The script is copied into every delivered Agent at
``agent-core/scripts/sync_accio_context.py``.  It deliberately synchronizes
only managed blocks.  Role-specific content, the Accio connected-account
block, credentials, and task artifacts remain outside its write scope.
"""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import logging
import os
import re
import tempfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any


LOGGER = logging.getLogger("sync_accio_context")
PROTOCOL_VERSION = "1"
USER_MARKER = "ACCIO_SHARED_USER"
MEMORY_MARKER = "ACCIO_SHARED_MEMORY"


class SyncError(RuntimeError):
    """Raised when context synchronization cannot be completed safely."""


@dataclass(frozen=True)
class AccioAssistant:
    """Describe the unique shared-memory source found in one Agent space.

    Attributes:
        agent_id: Directory/profile ID of the Accio Assistant.
        agent_core: Path to the source ``agent-core`` directory.
        profile: Parsed ``profile.jsonc`` object.
    """

    agent_id: str
    agent_core: Path
    profile: dict[str, Any]


def configure_logging() -> None:
    """Configure concise stderr logging for Agent and installer diagnostics."""

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")


def strip_jsonc_comments(text: str) -> str:
    """Remove JSONC comments without changing comment-like text in strings.

    Args:
        text: Raw JSON or JSONC content.

    Returns:
        JSON text accepted by :func:`json.loads`.

    Raises:
        SyncError: If a block comment is not closed.
    """

    output: list[str] = []
    index = 0
    in_string = False
    escaped = False
    while index < len(text):
        char = text[index]
        following = text[index + 1] if index + 1 < len(text) else ""
        if in_string:
            output.append(char)
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            index += 1
            continue
        if char == '"':
            in_string = True
            output.append(char)
            index += 1
            continue
        if char == "/" and following == "/":
            index += 2
            while index < len(text) and text[index] not in "\r\n":
                index += 1
            continue
        if char == "/" and following == "*":
            closing = text.find("*/", index + 2)
            if closing < 0:
                raise SyncError("profile.jsonc contains an unclosed block comment")
            index = closing + 2
            continue
        output.append(char)
        index += 1
    return "".join(output)


def read_jsonc(path: Path) -> dict[str, Any]:
    """Read one JSON/JSONC object.

    Args:
        path: Profile path.

    Returns:
        Parsed object.

    Raises:
        SyncError: If the file is missing, invalid, or not an object.
    """

    try:
        payload = json.loads(strip_jsonc_comments(path.read_text(encoding="utf-8")))
    except (OSError, json.JSONDecodeError) as exc:
        raise SyncError(f"cannot read profile: {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise SyncError(f"profile is not an object: {path}")
    return payload


def resolve_agent_core(explicit: Path | None) -> Path:
    """Resolve the target Agent core from CLI input or this script location.

    Args:
        explicit: Optional explicit ``agent-core`` path.

    Returns:
        Existing absolute ``agent-core`` path.

    Raises:
        SyncError: If the expected core files are absent.
    """

    candidate = explicit.expanduser().resolve() if explicit else Path(__file__).resolve().parents[1]
    if not (candidate / "USER.md").is_file() or not (candidate / "MEMORY.md").is_file():
        raise SyncError(f"not an Agent core directory: {candidate}")
    return candidate


def resolve_agents_root(agent_core: Path, explicit: Path | None) -> Path:
    """Resolve the current account/space ``agents`` directory.

    Args:
        agent_core: Target Agent core.
        explicit: Optional installer-provided agents root.

    Returns:
        Existing absolute agents root.

    Raises:
        SyncError: If the directory cannot be determined.
    """

    candidate = explicit.expanduser().resolve() if explicit else agent_core.parent.parent
    if not candidate.is_dir():
        raise SyncError(f"agents root does not exist: {candidate}")
    return candidate


def discover_accio_assistant(agents_root: Path, target_agent_dir: Path) -> AccioAssistant:
    """Find the unique enabled ``agentType: accio`` Agent in one space.

    Exact name ``Accio Assistant`` is used only to disambiguate multiple
    enabled Accio-type candidates.  IDs are never hard-coded.

    Args:
        agents_root: Current account/space agents directory.
        target_agent_dir: Agent currently being installed or run.

    Returns:
        Unique source Agent.

    Raises:
        SyncError: If no unique safe source exists.
    """

    candidates: list[AccioAssistant] = []
    for child in sorted(agents_root.iterdir(), key=lambda item: item.name):
        if not child.is_dir() or child.resolve() == target_agent_dir.resolve():
            continue
        profile_path = child / "profile.jsonc"
        if not profile_path.is_file():
            continue
        profile = read_jsonc(profile_path)
        if profile.get("agentType") != "accio" or profile.get("enabled", True) is not True:
            continue
        source_core = child / "agent-core"
        if (source_core / "USER.md").is_file() and (source_core / "MEMORY.md").is_file():
            candidates.append(AccioAssistant(str(profile.get("id") or child.name), source_core, profile))

    if len(candidates) == 1:
        return candidates[0]
    exact = [item for item in candidates if item.profile.get("name") == "Accio Assistant"]
    if len(exact) == 1:
        return exact[0]
    names = [str(item.profile.get("name") or item.agent_id) for item in candidates]
    if not candidates:
        raise SyncError("no enabled agentType=accio source with USER.md and MEMORY.md was found")
    raise SyncError(f"cannot choose one Accio Assistant from candidates: {names}")


def block_pattern(marker: str) -> re.Pattern[str]:
    """Create the managed-block pattern for one validated marker name."""

    if not re.fullmatch(r"[A-Z0-9_]+", marker):
        raise SyncError(f"invalid managed marker: {marker}")
    return re.compile(
        rf"<!--\s*{marker}:BEGIN(?P<meta>.*?)-->\s*(?P<body>.*?)\s*<!--\s*{marker}:END\s*-->",
        re.DOTALL,
    )


def extract_block(text: str, marker: str, source: Path) -> str:
    """Extract one and only one managed-block body.

    Args:
        text: Markdown content.
        marker: Managed block name.
        source: Path used in diagnostic messages.

    Returns:
        Trimmed block body.

    Raises:
        SyncError: If the marker is absent or duplicated.
    """

    matches = list(block_pattern(marker).finditer(text))
    if len(matches) != 1:
        raise SyncError(f"expected one {marker} block in {source}, found {len(matches)}")
    return matches[0].group("body").strip()


def digest_text(text: str) -> str:
    """Return a stable SHA-256 for synchronized Markdown content."""

    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def replace_block(text: str, marker: str, body: str, source: AccioAssistant, source_space: str) -> str:
    """Replace exactly one target managed block and preserve all other text.

    Args:
        text: Target Markdown.
        marker: Managed block name.
        body: Source block body.
        source: Source Accio Assistant metadata.
        source_space: Stable space label derived from the agents path.

    Returns:
        Updated Markdown.

    Raises:
        SyncError: If the target block is absent or duplicated.
    """

    pattern = block_pattern(marker)
    matches = list(pattern.finditer(text))
    if len(matches) != 1:
        raise SyncError(f"target requires exactly one {marker} block, found {len(matches)}")
    timestamp = datetime.now().astimezone().isoformat(timespec="seconds")
    replacement = (
        f"<!-- {marker}:BEGIN\n"
        f"source_agent_id: {source.agent_id}\n"
        f"source_space: {source_space}\n"
        f"synced_at: {timestamp}\n"
        f"content_sha256: {digest_text(body)}\n"
        f"protocol_version: {PROTOCOL_VERSION}\n"
        f"-->\n\n{body}\n\n<!-- {marker}:END -->"
    )
    return text[: matches[0].start()] + replacement + text[matches[0].end() :]


def atomic_write(path: Path, text: str) -> None:
    """Write UTF-8 text through a same-directory temporary file.

    Args:
        path: Existing Markdown file.
        text: Complete replacement content.

    Raises:
        OSError: If writing or atomic replacement fails.
    """

    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
        handle.write(text)
        handle.flush()
        os.fsync(handle.fileno())
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def merge_candidate(existing: str, candidate_path: Path | None) -> str:
    """Append a reviewed candidate snippet unless it already exists verbatim.

    Args:
        existing: Existing source managed-block body.
        candidate_path: Optional UTF-8 Markdown snippet.

    Returns:
        Merged body.

    Raises:
        SyncError: If the candidate cannot be read.
    """

    if candidate_path is None:
        return existing
    try:
        candidate = candidate_path.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise SyncError(f"cannot read candidate file: {candidate_path}: {exc}") from exc
    if not candidate or candidate in existing:
        return existing
    return f"{existing.rstrip()}\n\n{candidate}".strip()


def pull(agent_core: Path, agents_root: Path, source: AccioAssistant) -> dict[str, Any]:
    """Pull shared USER and MEMORY bodies into one target Agent.

    Args:
        agent_core: Target Agent core.
        agents_root: Same-space agents directory.
        source: Discovered Accio Assistant.

    Returns:
        Machine-readable synchronization summary.

    Raises:
        SyncError: If source/target blocks are invalid.
        OSError: If files cannot be updated.
    """

    source_user_path = source.agent_core / "USER.md"
    source_memory_path = source.agent_core / "MEMORY.md"
    source_user = extract_block(source_user_path.read_text(encoding="utf-8"), USER_MARKER, source_user_path)
    source_memory = extract_block(
        source_memory_path.read_text(encoding="utf-8"), MEMORY_MARKER, source_memory_path
    )
    if not source_user and not source_memory:
        raise SyncError("both Accio Assistant shared blocks are empty; initialize the shared context first")

    target_user_path = agent_core / "USER.md"
    target_memory_path = agent_core / "MEMORY.md"
    target_user = replace_block(
        target_user_path.read_text(encoding="utf-8"), USER_MARKER, source_user, source, agents_root.parent.name
    )
    target_memory = replace_block(
        target_memory_path.read_text(encoding="utf-8"),
        MEMORY_MARKER,
        source_memory,
        source,
        agents_root.parent.name,
    )
    atomic_write(target_user_path, target_user)
    atomic_write(target_memory_path, target_memory)
    return {
        "status": "synchronized",
        "sourceAgentId": source.agent_id,
        "sourceAgentName": source.profile.get("name"),
        "space": agents_root.parent.name,
        "userSha256": digest_text(source_user),
        "memorySha256": digest_text(source_memory),
        "protocolVersion": PROTOCOL_VERSION,
    }


def push(
    agent_core: Path,
    agents_root: Path,
    source: AccioAssistant,
    user_candidate: Path | None,
    memory_candidate: Path | None,
) -> dict[str, Any]:
    """Merge reviewed shared candidates into the Accio Assistant, then pull.

    Args:
        agent_core: Calling Agent core.
        agents_root: Same-space agents directory.
        source: Discovered Accio Assistant.
        user_candidate: Optional shared USER snippet.
        memory_candidate: Optional shared MEMORY snippet.

    Returns:
        Synchronization summary after write-back and pull.

    Raises:
        SyncError: If neither candidate is provided or markers are invalid.
        OSError: If locking or writing fails.
    """

    if user_candidate is None and memory_candidate is None:
        raise SyncError("push requires --user-candidate and/or --memory-candidate")
    lock_path = source.agent_core / ".accio-context-sync.lock"
    with lock_path.open("a+", encoding="utf-8") as lock_handle:
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
        for filename, marker, candidate in (
            ("USER.md", USER_MARKER, user_candidate),
            ("MEMORY.md", MEMORY_MARKER, memory_candidate),
        ):
            if candidate is None:
                continue
            path = source.agent_core / filename
            text = path.read_text(encoding="utf-8")
            body = extract_block(text, marker, path)
            merged = merge_candidate(body, candidate)
            if merged != body:
                # Keep source marker metadata untouched; it describes the shared
                # block itself, while target snapshots carry sync provenance.
                match = block_pattern(marker).search(text)
                if match is None:
                    raise SyncError(f"missing source block while pushing: {path}")
                replacement = text[match.start() : match.start("body")] + merged + text[match.end("body") : match.end()]
                atomic_write(path, text[: match.start()] + replacement + text[match.end() :])
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)
    result = pull(agent_core, agents_root, source)
    result["writeBack"] = True
    return result


def main() -> int:
    """Run install/pull/verify/push mode and print one JSON result.

    Returns:
        Process exit code. ``0`` means the requested operation completed;
        ``2`` means synchronization was safely refused.
    """

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("install", "pull", "verify", "push"))
    parser.add_argument("--agent-core", type=Path, help="target agent-core directory")
    parser.add_argument("--agents-root", type=Path, help="same-space agents directory")
    parser.add_argument("--user-candidate", type=Path, help="reviewed USER Markdown snippet for push")
    parser.add_argument("--memory-candidate", type=Path, help="reviewed MEMORY Markdown snippet for push")
    args = parser.parse_args()
    configure_logging()

    try:
        agent_core = resolve_agent_core(args.agent_core)
        agents_root = resolve_agents_root(agent_core, args.agents_root)
        source = discover_accio_assistant(agents_root, agent_core.parent)
        if args.mode == "verify":
            user_body = extract_block(
                (source.agent_core / "USER.md").read_text(encoding="utf-8"),
                USER_MARKER,
                source.agent_core / "USER.md",
            )
            memory_body = extract_block(
                (source.agent_core / "MEMORY.md").read_text(encoding="utf-8"),
                MEMORY_MARKER,
                source.agent_core / "MEMORY.md",
            )
            result: dict[str, Any] = {
                "status": "ready",
                "sourceAgentId": source.agent_id,
                "userSha256": digest_text(user_body),
                "memorySha256": digest_text(memory_body),
                "protocolVersion": PROTOCOL_VERSION,
            }
        elif args.mode == "push":
            result = push(
                agent_core,
                agents_root,
                source,
                args.user_candidate,
                args.memory_candidate,
            )
        else:
            result = pull(agent_core, agents_root, source)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, SyncError) as exc:
        LOGGER.error("%s", exc)
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
