#!/usr/bin/env python3
"""Validate English B2B product titles before they are delivered."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any


MIN_LENGTH = 110
MAX_LENGTH = 120
FORBIDDEN_SYMBOLS = frozenset("@!?$^{~\\，")
PREPOSITION_PATTERN = re.compile(r"\b(?:for|with)\b", re.IGNORECASE)


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments.

    Returns:
        Parsed arguments containing the UTF-8 input file path.

    Raises:
        SystemExit: If ``--input`` is missing or malformed.
    """

    parser = argparse.ArgumentParser(
        description="Validate one English product title per UTF-8 text line."
    )
    parser.add_argument(
        "--input",
        required=True,
        type=Path,
        help="UTF-8 text file; each non-empty line is one title, optionally T1<TAB>Title.",
    )
    return parser.parse_args()


def split_title_line(line: str, sequence: int) -> tuple[str, str]:
    """Extract an optional title ID and the title text from one input line.

    Args:
        line: One non-empty input line.
        sequence: One-based fallback sequence number.

    Returns:
        A ``(title_id, title)`` pair. A tab separates an explicit ID from title text.

    Raises:
        No exceptions are expected.
    """

    if "\t" in line:
        title_id, title = line.split("\t", 1)
        return title_id.strip() or f"T{sequence}", title.strip()
    return f"T{sequence}", line.strip()


def validate_title(title_id: str, title: str) -> dict[str, Any]:
    """Validate one title against deterministic delivery gates.

    Args:
        title_id: Stable title identifier used in the validation report.
        title: English title text whose spaces and punctuation count toward length.

    Returns:
        A JSON-serializable result containing actual character count, errors, and status.

    Raises:
        No exceptions are expected. Validation failures are returned as data so the
        Agent can rewrite only the affected titles and rerun the complete batch.
    """

    errors: list[str] = []
    character_count = len(title)
    if character_count < MIN_LENGTH:
        errors.append(f"too_short:{character_count}<{MIN_LENGTH}")
    if character_count > MAX_LENGTH:
        errors.append(f"too_long:{character_count}>{MAX_LENGTH}")

    forbidden_found = sorted(set(title).intersection(FORBIDDEN_SYMBOLS))
    if forbidden_found:
        errors.append(f"forbidden_symbols:{''.join(forbidden_found)}")

    prepositions = PREPOSITION_PATTERN.findall(title)
    if len(prepositions) > 1:
        errors.append(f"for_with_count:{len(prepositions)}>1")

    if title.isupper() and any(character.isalpha() for character in title):
        errors.append("all_uppercase")

    return {
        "id": title_id,
        "title": title,
        "characterCount": character_count,
        "valid": not errors,
        "errors": errors,
    }


def validate_file(input_path: Path) -> dict[str, Any]:
    """Read and validate a complete title batch.

    Args:
        input_path: UTF-8 text file containing one title per non-empty line.

    Returns:
        A batch report with per-title results and aggregate pass/fail counts.

    Raises:
        FileNotFoundError: If the input file does not exist.
        UnicodeDecodeError: If the input file is not valid UTF-8.
        ValueError: If the file contains no non-empty title lines.
    """

    raw_lines = input_path.read_text(encoding="utf-8").splitlines()
    title_lines = [line.strip() for line in raw_lines if line.strip()]
    if not title_lines:
        raise ValueError("input file contains no titles")

    results = [
        validate_title(*split_title_line(line, sequence))
        for sequence, line in enumerate(title_lines, start=1)
    ]
    failed = sum(not item["valid"] for item in results)
    return {
        "status": "passed" if failed == 0 else "failed",
        "titleCount": len(results),
        "passedCount": len(results) - failed,
        "failedCount": failed,
        "minRequired": MIN_LENGTH,
        "maxRequired": MAX_LENGTH,
        "results": results,
    }


def main() -> int:
    """Run the validator and print a machine-readable JSON report.

    Returns:
        Exit code ``0`` when every title passes, ``1`` for title validation failures,
        or ``2`` when the input file cannot be read or parsed.

    Raises:
        No exceptions escape this function; operational errors are returned as JSON.
    """

    args = parse_args()
    try:
        report = validate_file(args.input)
    except (OSError, UnicodeError, ValueError) as exc:
        print(
            json.dumps(
                {"status": "error", "error": str(exc)},
                ensure_ascii=False,
                indent=2,
            )
        )
        return 2

    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    sys.exit(main())
