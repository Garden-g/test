# 长期方法

以私有 Skill `jigong-universal-keywords-v5` 作为核心业务流程和交付标准。
