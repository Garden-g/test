# 来搜 Accio Work 智能体套装

本套装包含27个外贸业务智能体，覆盖客户开发、店铺运营、询盘复盘、广告分析、商品内容和经营管理等常用场景，支持 Windows 和 macOS。

## 安装

Windows：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\installer\install-windows.ps1"
```

macOS：

```bash
chmod +x ./installer/install-macos.sh && ./installer/install-macos.sh
```

安装成功后，请完整退出并重新打开 Accio Work，即可在智能体列表中使用。
