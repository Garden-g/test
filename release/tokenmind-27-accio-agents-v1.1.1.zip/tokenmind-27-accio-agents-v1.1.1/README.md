# TokenMind 27 个 Accio Work 智能体套装

版本：1.1.1

本包适用于 Windows 和 macOS，包含 27 个一对一智能体。每个智能体只内置一个对应的完整私有 Skill，并统一使用同一张 Logo。

Skill 来源：wmWW-G/WM_Skill@f207a2e5bb7d7c7f50452e26d3dbc55b4b5ba8fb

## 安装

- Windows：`powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\installer\install-windows.ps1"`
- macOS：`chmod +x ./installer/install-macos.sh && ./installer/install-macos.sh`

安装器会识别当前 Accio 个人或团队空间，为每个 Agent 生成唯一 `MID-*`，保留私有 Skill 和统一 Logo，禁止覆盖已有 Agent。安装后会从当前空间 `agentType=accio` 的主智能体读取本地 `USER.md` 和 `MEMORY.md`，以 TokenMind 标记块合并到27个 Agent。

请勿转发安装完成后的 Agent 目录，因为其中会包含当前账号的本地用户画像和记忆。安装器不会主动结束或重启 Accio Work；成功后请手动完整退出并重新打开。
